/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

import express from "express";
import path from "path";
import { fileURLToPath } from "url";
import { createServer as createViteServer } from "vite";
import { GoogleGenAI, Type } from "@google/genai";
import dotenv from "dotenv";

// Load environment variables
dotenv.config();

const __filename = fileURLToPath(import.meta.url);
const __dirname = path.dirname(__filename);

async function startServer() {
  const app = express();
  const PORT = 3000;

  // Middleware for parsing JSON requests
  app.use(express.json({ limit: "15mb" }));

  // Initialize Gemini client using GoogleGenAI SDK
  // We check for the key gracefully to prevent startup crashes when running without it
  const apiKey = process.env.GEMINI_API_KEY;
  let ai: GoogleGenAI | null = null;
  if (apiKey) {
    ai = new GoogleGenAI({
      apiKey: apiKey,
      httpOptions: {
        headers: {
          "User-Agent": "aistudio-build",
        },
      },
    });
    console.log("Gemini AI client successfully initialized server-side.");
  } else {
    console.warn("WARNING: GEMINI_API_KEY is not defined in the environment. The AI assistant will operate in limited/offline mode.");
  }

  // API Endpoints: AI Chat and Operations Proxy
  app.post("/api/chat", async (req, res) => {
    const { message, people, projects, allocations } = req.body;

    if (!message) {
      return res.status(400).json({ error: "Message prompt is required." });
    }

    if (!ai) {
      return res.status(503).json({
        reply: "AI assistant is temporarily unavailable because the server is missing the `GEMINI_API_KEY` configuration. Please make sure to configure it in the Secrets panel in AI Studio.",
        actionApplied: null,
        updatedPeople: people,
        updatedProjects: projects,
        updatedAllocations: allocations,
      });
    }

    try {
      // Define system prompt detailing constraints, data formats, and how updates should be structured
      const currentDateString = "2026-06-03";
      const systemInstruction = `You are a professional Resource and Project Planning AI Assistant.
The current date is ${currentDateString}. All team schedules are focused on the Q3/Q4 2026 timeline.

You have access to the portfolio's active dataset:
- People (name, role, team, skills, capacity percentage, and registered timeOff)
- Projects (name, description, start/end dates, priority, and requiredSkills)
- Allocations (who is assigned to what, what date range, and what percentage, where 100% means full time)

**What you can do:**
1. **Analyze Data & Answer Questions:** Answer plain-English questions about workloads, over-allocations, gaps, skills, timeline crunch periods, and portfolio health. Be direct, clear, mathematically exact, and helpful. Use simple formatting (tables, lists, bold terms) in your text.
2. **Execute Structured Changes:** If the user asks you to add, edit, or remove resources, projects, or allocations, you MUST modify the provided arrays and return the complete updated arrays. For example:
   - "move Priya off Project Atlas by 20%" -> Locate Priya's allocation on Project Atlas, reduce its percentage by 20% (e.g. from 50% to 30%), and update the allocations array.
   - "add a new project called Helix starting in August that needs two engineers" -> Create a project called "Project Helix", start date "2026-08-01", end date "2026-12-31" (or similar default end), priority "Medium", and return it in updatedProjects. Wire it in.
   - If you need to create a new person, project, or allocation, invent a unique string ID for it (e.g., 'person-helix', 'proj-123', 'alloc-456').

**Key rules when making changes:**
- Validate roles, dates, and overlaps.
- Generate realistic, structured updates.
- If you made structural updates, write a concise, one-sentence description in the 'actionApplied' field (e.g., "Assigned Sarah Jenkins to Project Beacon at 30% allocation").
- If the request is purely informational (e.g. a question like "Who is over-allocated?"), do NOT change any fields in the arrays. Return the exact people, projects, and allocations arrays as they were passed to you, and set 'actionApplied' to null or empty string.

Be structured, warm, professional, and clear. Avoid engineering jargon.`;

      // Set up structured Response Schema to get precise JSON
      const responseSchema = {
        type: Type.OBJECT,
        properties: {
          reply: {
            type: Type.STRING,
            description: "Friendly plain-English Markdown response detailing answer or results of structural action. Use structured bullet points or small markdown tables to present timeline or analysis clearly.",
          },
          actionApplied: {
            type: Type.STRING,
            description: "Short 1-sentence recap of what structural change was made (e.g. 'Added Project Helix starting in August'). Set to empty or null if it was just a question.",
          },
          updatedPeople: {
            type: Type.ARRAY,
            description: "The complete array of all people. If you modified, added, or deleted a person, output the final full array. Otherwise output exactly what was sent in.",
            items: {
              type: Type.OBJECT,
              properties: {
                id: { type: Type.STRING },
                name: { type: Type.STRING },
                role: { type: Type.STRING },
                team: { type: Type.STRING },
                skills: { type: Type.ARRAY, items: { type: Type.STRING } },
                capacityPercent: { type: Type.INTEGER },
                timeOff: {
                  type: Type.ARRAY,
                  items: {
                    type: Type.OBJECT,
                    properties: {
                      id: { type: Type.STRING },
                      description: { type: Type.STRING },
                      startDate: { type: Type.STRING },
                      endDate: { type: Type.STRING },
                    },
                    required: ["id", "description", "startDate", "endDate"],
                  },
                },
              },
              required: ["id", "name", "role", "team", "skills", "capacityPercent", "timeOff"],
            },
          },
          updatedProjects: {
            type: Type.ARRAY,
            description: "The complete array of all projects. If you modified, added, or deleted a project, output the final full array. Otherwise output exactly what was sent in.",
            items: {
              type: Type.OBJECT,
              properties: {
                id: { type: Type.STRING },
                name: { type: Type.STRING },
                description: { type: Type.STRING },
                startDate: { type: Type.STRING },
                endDate: { type: Type.STRING },
                priority: { type: Type.STRING },
                requiredSkills: { type: Type.ARRAY, items: { type: Type.STRING } },
              },
              required: ["id", "name", "description", "startDate", "endDate", "priority", "requiredSkills"],
            },
          },
          updatedAllocations: {
            type: Type.ARRAY,
            description: "The complete array of all allocations. If you modified, added, or deleted allocations, output the final full array. Otherwise output exactly what was sent in.",
            items: {
              type: Type.OBJECT,
              properties: {
                id: { type: Type.STRING },
                personId: { type: Type.STRING },
                projectId: { type: Type.STRING },
                percentage: { type: Type.INTEGER },
                startDate: { type: Type.STRING },
                endDate: { type: Type.STRING },
              },
              required: ["id", "personId", "projectId", "percentage", "startDate", "endDate"],
            },
          },
        },
        required: ["reply", "actionApplied", "updatedPeople", "updatedProjects", "updatedAllocations"],
      };

      // Call the Gemini model
      const contentsPayload = `User Prompt: "${message}"\n\nCURRENT PORTFOLIO STATE:\n\nPEOPLE:\n${JSON.stringify(people, null, 2)}\n\nPROJECTS:\n${JSON.stringify(projects, null, 2)}\n\nALLOCATIONS:\n${JSON.stringify(allocations, null, 2)}`;

      const modelResponse = await ai.models.generateContent({
        model: "gemini-3.5-flash",
        contents: contentsPayload,
        config: {
          systemInstruction,
          responseMimeType: "application/json",
          responseSchema,
          temperature: 0.1, // low temperature to ensure reliable database edits and query answers
        },
      });

      // Parse and send the response back
      const textResult = modelResponse.text?.trim() || "{}";
      const parsedResult = JSON.parse(textResult);
      res.json(parsedResult);

    } catch (error: any) {
      console.error("Gemini api/chat Error:", error);
      res.status(500).json({
        error: "Failed to process message with Gemini AI.",
        details: error.message || error,
        reply: "Sorry, I had an error analyzing the request. Please modify the plan manually or try again in a moment.",
        actionApplied: null,
        updatedPeople: people,
        updatedProjects: projects,
        updatedAllocations: allocations,
      });
    }
  });

  // Client-Side Dev environment vs Production build config
  if (process.env.NODE_ENV !== "production") {
    const vite = await createViteServer({
      server: { middlewareMode: true },
      appType: "spa",
    });
    app.use(vite.middlewares);
  } else {
    const distPath = path.join(process.cwd(), "dist");
    app.use(express.static(distPath));
    app.get("*", (req, res) => {
      res.sendFile(path.join(distPath, "index.html"));
    });
  }

  app.listen(PORT, "0.0.0.0", () => {
    console.log(`Resource and Project Planner server is running on http://localhost:${PORT}`);
  });
}

startServer();
