/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

import React, { useState } from 'react';
import { Person, Project, Allocation } from '../types';
import { Sparkles, Calendar, Umbrella, AlertCircle, HelpCircle } from 'lucide-react';

interface TimelineViewProps {
  people: Person[];
  projects: Project[];
  allocations: Allocation[];
  filters: {
    team: string;
    skill: string;
    project: string;
    search: string;
  };
  onRequestAiHelp?: (prompt: string) => void;
}

const PLANNING_MONTHS = [
  { name: 'Jun', fullName: 'June 2026', start: '2026-06-01', end: '2026-06-30' },
  { name: 'Jul', fullName: 'July 2026', start: '2026-07-01', end: '2026-07-31' },
  { name: 'Aug', fullName: 'August 2026', start: '2026-08-01', end: '2026-08-31' },
  { name: 'Sep', fullName: 'September 2026', start: '2026-09-01', end: '2026-09-30' },
  { name: 'Oct', fullName: 'October 2026', start: '2026-10-01', end: '2026-10-31' },
  { name: 'Nov', fullName: 'November 2026', start: '2026-11-01', end: '2026-11-30' },
  { name: 'Dec', fullName: 'December 2026', start: '2026-12-01', end: '2026-12-31' }
];

export default function TimelineView({ people, projects, allocations, filters, onRequestAiHelp }: TimelineViewProps) {
  const [hoveredCell, setHoveredCell] = useState<{ personId: string; monthIndex: number } | null>(null);

  // Helper to check if dates overlap
  const datesOverlap = (startA: string, endA: string, startB: string, endB: string) => {
    return startA <= endB && endA >= startB;
  };

  // Filter people based on parent states
  const filteredPeople = people.filter(p => {
    // Team filter
    if (filters.team && p.team !== filters.team) return false;
    
    // Skill filter
    if (filters.skill && !p.skills.includes(filters.skill)) return false;
    
    // Search query matches name, role or skills
    if (filters.search) {
      const q = filters.search.toLowerCase();
      const matchesName = p.name.toLowerCase().includes(q);
      const matchesRole = p.role.toLowerCase().includes(q);
      const matchesSkills = p.skills.some(s => s.toLowerCase().includes(q));
      if (!matchesName && !matchesRole && !matchesSkills) return false;
    }
    
    // Project filter
    if (filters.project) {
      const personProjectIds = allocations
        .filter(a => a.personId === p.id)
        .map(a => a.projectId);
      if (!personProjectIds.includes(filters.project)) return false;
    }

    return true;
  });

  return (
    <div id="timeline-panel" className="bg-white rounded-2xl border border-gray-100 shadow-xs p-6 mb-6">
      <div className="flex flex-col sm:flex-row items-start sm:items-center justify-between mb-4 pb-4 border-b border-gray-100">
        <div>
          <h2 className="text-lg font-display font-bold text-gray-950 flex items-center gap-2">
            <Calendar className="h-5 w-5 text-indigo-600" />
            Resource Allocation Heatmap
          </h2>
          <p id="timeline-subtitle" className="text-xs text-gray-500">
            Peak workload percentage against employee capacity threshold (e.g. 100% full-time) across coming months.
          </p>
        </div>
        <div id="timeline-legend" className="flex flex-wrap items-center gap-3 mt-2 sm:mt-0 text-[11px] text-gray-500 font-mono">
          <div className="flex items-center gap-1.5">
            <span className="w-2.5 h-2.5 rounded bg-red-100 border border-red-300 inline-block"></span>
            <span>Over (&gt;100%)</span>
          </div>
          <div className="flex items-center gap-1.5">
            <span className="w-2.5 h-2.5 rounded bg-green-100 border border-green-300 inline-block"></span>
            <span>Fully Loaded (80-100%)</span>
          </div>
          <div className="flex items-center gap-1.5">
            <span className="w-2.5 h-2.5 rounded bg-indigo-50 border border-indigo-200 inline-block"></span>
            <span>Comfortable (1-79%)</span>
          </div>
          <div className="flex items-center gap-1.5">
            <span className="w-2.5 h-2.5 rounded bg-gray-50 border border-gray-200 inline-block"></span>
            <span>Idle (0%)</span>
          </div>
          <div className="flex items-center gap-1.5">
            <span className="text-xs">🌴</span>
            <span>Vacation/Off</span>
          </div>
        </div>
      </div>

      <div className="overflow-x-auto">
        <table id="timeline-table" className="w-full min-w-[700px]">
          <thead>
            <tr className="border-b border-gray-100 text-left text-xs text-gray-400 font-mono tracking-wider">
              <th className="py-3 px-4 font-semibold w-[250px]">RESOURCE / ROLE</th>
              {PLANNING_MONTHS.map(m => (
                <th key={m.name} className="py-3 px-3 text-center font-semibold">{m.fullName}</th>
              ))}
            </tr>
          </thead>
          <tbody className="divide-y divide-gray-50">
            {filteredPeople.length === 0 ? (
              <tr>
                <td colSpan={PLANNING_MONTHS.length + 1} className="py-8 text-center text-sm text-gray-400">
                  No people found matching current filter configuration.
                </td>
              </tr>
            ) : (
              filteredPeople.map(p => {
                return (
                  <tr key={p.id} className="hover:bg-gray-50/50 transition">
                    <td className="py-4 px-4">
                      <div>
                        <div className="font-semibold text-gray-900 text-sm">{p.name}</div>
                        <div className="text-xs text-gray-500 font-mono flex items-center gap-1.5">
                          <span className="bg-slate-100 text-slate-700 px-1.5 py-0.5 rounded text-[10px]">
                            {p.team}
                          </span>
                          <span>{p.role}</span>
                        </div>
                      </div>
                    </td>

                    {PLANNING_MONTHS.map((m, monthIndex) => {
                      // Calculate active allocations for this person overlapping this month
                      const activeAllocs = allocations.filter(a => 
                        a.personId === p.id && datesOverlap(a.startDate, a.endDate, m.start, m.end)
                      );

                      // Sum up percentages
                      const totalAlloc = activeAllocs.reduce((sum, a) => sum + a.percentage, 0);
                      
                      // Check if person has registered time off in this month
                      const hasPTO = p.timeOff.some(to => 
                        datesOverlap(to.startDate, to.endDate, m.start, m.end)
                      );
                      const matchingPTOEvents = p.timeOff.filter(to => 
                        datesOverlap(to.startDate, to.endDate, m.start, m.end)
                      );

                      // Determine color status
                      let bgClass = 'bg-gray-50 text-gray-400 border-gray-200/50';
                      let labelColor = 'text-gray-400';
                      
                      if (totalAlloc > p.capacityPercent) {
                        bgClass = 'bg-red-50 text-red-700 border-red-200 font-bold';
                        labelColor = 'text-red-600';
                      } else if (totalAlloc >= 80 && totalAlloc <= p.capacityPercent) {
                        bgClass = 'bg-emerald-50 text-emerald-700 border-emerald-200 font-medium';
                        labelColor = 'text-emerald-700';
                      } else if (totalAlloc > 0) {
                        bgClass = 'bg-indigo-50/70 text-indigo-700 border-indigo-100';
                        labelColor = 'text-indigo-600';
                      }

                      const isHovered = hoveredCell?.personId === p.id && hoveredCell?.monthIndex === monthIndex;

                      return (
                        <td 
                          key={m.name} 
                          className="py-3 px-2 text-center relative"
                          onMouseEnter={() => setHoveredCell({ personId: p.id, monthIndex })}
                          onMouseLeave={() => setHoveredCell(null)}
                        >
                          <div 
                            onClick={() => {
                              if (onRequestAiHelp) {
                                onRequestAiHelp(`Analyze workload details for ${p.name} during ${m.fullName}. Detail their active allocations (${totalAlloc}%), check for vacation schedules or skill requirements, and suggest adjustments if they are over-committed.`);
                              }
                            }}
                            className={`mx-auto w-14 py-2 px-1 rounded-xl border flex flex-col items-center justify-center text-xs transition duration-150 cursor-pointer hover:scale-105 active:scale-95 relative hover:border-indigo-400 hover:shadow-xs select-none ${bgClass}`}
                            title={`Click to analyze ${p.name}'s workload with AI`}
                          >
                            <span className="font-mono text-[11px]">{totalAlloc}%</span>
                            {hasPTO && (
                              <span className="absolute -top-1.5 -right-1 bg-amber-100 text-amber-805 border border-amber-200 text-[10px] w-4 h-4 rounded-full flex items-center justify-center animate-bounce" title="Palm Tree Vacation scheduled">
                                🌴
                              </span>
                            )}
                          </div>

                          {/* Interactive Hover Tooltip detailing assignments or PTO overlapping this month */}
                          {isHovered && (
                            <div className="absolute z-10 bottom-full left-1/2 transform -translate-x-1/2 mb-2 bg-slate-900 border border-slate-800 text-white rounded-xl p-3 shadow-xl text-left w-60 space-y-2 pointer-events-none text-xs">
                              <p className="font-bold border-b border-slate-800 pb-1 text-[11px] font-mono uppercase tracking-wider text-slate-400">{m.fullName}</p>
                              
                              {activeAllocs.length > 0 ? (
                                <div className="space-y-1">
                                  <p className="font-semibold text-slate-300">Staff Assignments:</p>
                                  {activeAllocs.map(a => {
                                    const proj = projects.find(pr => pr.id === a.projectId);
                                    return (
                                      <div key={a.id} className="flex justify-between items-center text-[10px]">
                                        <span className="text-white truncate max-w-[150px]">{proj ? proj.name : 'Unknown project'}</span>
                                        <span className="font-mono bg-slate-805 px-1 border border-slate-700/65 text-indigo-400 rounded font-semibold">{a.percentage}%</span>
                                      </div>
                                    );
                                  })}
                                </div>
                              ) : (
                                <p className="text-slate-450 italic">No project assignments active.</p>
                              )}

                              {matchingPTOEvents.length > 0 && (
                                <div className="border-t border-slate-800/80 pt-1.5 space-y-1">
                                  <p className="font-semibold text-amber-300 flex items-center gap-1">
                                    <Umbrella className="h-3 w-3" /> Time Off Scheduled:
                                  </p>
                                  {matchingPTOEvents.map(to => (
                                    <div key={to.id} className="text-[10px]">
                                      <p className="text-amber-100">{to.description}</p>
                                      <p className="text-slate-400 text-[9px] font-mono">({to.startDate} to {to.endDate})</p>
                                    </div>
                                  ))}
                                </div>
                              )}

                              <div className="border-t border-slate-800 pt-1.5 text-[10px] text-slate-400 flex justify-between">
                                <span>Employee Limit:</span>
                                <span className="font-mono font-semibold text-white">{p.capacityPercent}%</span>
                              </div>

                              <div className="border-t border-indigo-950 pt-1.5 text-[9px] text-indigo-400 font-bold flex items-center justify-center gap-1">
                                <Sparkles className="h-2.5 w-2.5 animate-pulse" />
                                <span>Click to Optimize load with AI</span>
                              </div>
                            </div>
                          )}
                        </td>
                      );
                    })}
                  </tr>
                );
              })
            )}
          </tbody>
        </table>
      </div>
    </div>
  );
}
