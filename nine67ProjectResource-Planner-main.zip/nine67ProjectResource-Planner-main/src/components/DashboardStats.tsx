/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

import React from 'react';
import { Person, Project, Allocation } from '../types';
import { Users, FolderKanban, AlertTriangle, Activity, CalendarClock, Sparkles, ChevronRight } from 'lucide-react';

interface DashboardStatsProps {
  people: Person[];
  projects: Project[];
  allocations: Allocation[];
  onRequestAiHelp?: (prompt: string) => void;
}

export default function DashboardStats({ people, projects, allocations, onRequestAiHelp }: DashboardStatsProps) {
  // 1. Calculate Capacity vs Demand (in % terms)
  const totalCapacity = people.reduce((sum, p) => sum + p.capacityPercent, 0);
  const totalAllocated = allocations.reduce((sum, a) => sum + a.percentage, 0);
  const utilization = totalCapacity > 0 ? Math.round((totalAllocated / totalCapacity) * 100) : 0;

  // 2. Count over-allocated people (>100% total allocation)
  const overAllocatedCount = people.filter(person => {
    const personAllocs = allocations.filter(a => a.personId === person.id);
    const totalAllocPercent = personAllocs.reduce((sum, a) => sum + a.percentage, 0);
    return totalAllocPercent > person.capacityPercent;
  }).length;

  // 3. Count projects with skill gaps
  const projectGapsCount = projects.filter(project => {
    const projectAllocs = allocations.filter(a => a.projectId === project.id);
    const staffedPeopleIds = projectAllocs.map(a => a.personId);
    const staffedPeople = people.filter(p => staffedPeopleIds.includes(p.id));
    
    // Accumulate all staffed skills
    const staffedSkills = new Set<string>();
    staffedPeople.forEach(p => p.skills.forEach(s => staffedSkills.add(s)));

    // Check if any required skill is missing
    return project.requiredSkills.some(skill => !staffedSkills.has(skill));
  }).length;

  // 4. Count upcoming Time Off
  const timeOffCount = people.reduce((sum, p) => sum + p.timeOff.length, 0);

  const triggerStatsHelp = (type: 'utilization' | 'overallocated' | 'gaps' | 'pto') => {
    if (!onRequestAiHelp) return;
    
    let prompt = '';
    switch (type) {
      case 'utilization':
        prompt = `Review key capacity index. Total allocated FTE is ${totalAllocated}% out of ${totalCapacity}% target constraints (Utilization: ${utilization}%). Give details on active demand balance, pinpoint where teams are running loaded vs under-leveraged, and suggest optimization adjustments.`;
        break;
      case 'overallocated':
        prompt = `Generate a fast tactical overallocation report. There are currently ${overAllocatedCount} over-committed resources in the team. Pinpoint exactly who has exceeded their capacity thresholds, detail which projects are causing the overlaps, and propose risk mitigations.`;
        break;
      case 'gaps':
        prompt = `Examine portfolio skill deficits. We have ${projectGapsCount} understaffed projects with unresolved competency requirements. Identify which projects represent critical priority level constraints, and review the team directory for perfect resource matches with those competencies and timeline bandwidth.`;
        break;
      case 'pto':
        prompt = `Analyze planned vacations schedules. We have ${timeOffCount} PTO blocks logged. Explain what risk level scheduled holidays represent to delivery milestones over the coming calendar, and suggest immediate cross-training or handoff strategies.`;
        break;
    }
    onRequestAiHelp(prompt);
  };

  return (
    <div id="dashboard-stats-grid" className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-4 mb-6">
      
      {/* Total Capacity Widget */}
      <div 
        id="stat-capacity" 
        onClick={() => triggerStatsHelp('utilization')}
        className="bg-white p-5 rounded-2xl border border-gray-100 shadow-xs hover:border-indigo-200 hover:shadow-xs transition duration-200 cursor-pointer group flex flex-col justify-between"
        title="Click to analyze portfolio utilization with AI"
      >
        <div>
          <div className="flex items-center justify-between mb-3">
            <span className="text-xs font-bold text-gray-400 uppercase tracking-widest font-mono">Portfolio Utilization</span>
            <div className="p-2 bg-indigo-50 text-indigo-600 rounded-xl group-hover:bg-indigo-100 transition">
              <Activity className="h-4.5 w-4.5" />
            </div>
          </div>
          <div className="flex items-baseline space-x-1.5">
            <span className="text-3xl font-display font-black text-gray-950">{utilization}%</span>
            <span className="text-[10px] text-gray-400 font-bold font-mono">
              ({totalAllocated}% / {totalCapacity}% FTE)
            </span>
          </div>
          <div className="mt-3.5 w-full bg-gray-100 rounded-full h-1.5 overflow-hidden">
            <div 
              className={`h-1.5 rounded-full transition-all duration-500 ${
                utilization > 90 ? 'bg-amber-500' : 'bg-indigo-600'
              }`}
              style={{ width: `${Math.min(utilization, 100)}%` }}
            />
          </div>
        </div>
        <div className="mt-4 pt-2 border-t border-gray-50 flex items-center justify-between text-[10px] font-bold text-indigo-600 group-hover:text-indigo-700">
          <span className="flex items-center gap-1">
            <Sparkles className="h-3 w-3 animate-pulse" />
            Analyze capacity index
          </span>
          <ChevronRight className="h-3.5 w-3.5 transform group-hover:translate-x-0.5 transition" />
        </div>
      </div>

      {/* Over-Allocated Count Widget */}
      <div 
        id="stat-overallocated" 
        onClick={() => triggerStatsHelp('overallocated')}
        className="bg-white p-5 rounded-2xl border border-gray-100 shadow-xs hover:border-red-200 hover:shadow-xs transition duration-200 cursor-pointer group flex flex-col justify-between"
        title="Click to generate an over-allocation risk report with AI"
      >
        <div>
          <div className="flex items-center justify-between mb-3">
            <span className="text-xs font-bold text-gray-400 uppercase tracking-widest font-mono">Over-committed staff</span>
            <div className={`p-2 rounded-xl transition ${overAllocatedCount > 0 ? 'bg-rose-50 text-rose-600 group-hover:bg-rose-100' : 'bg-emerald-50 text-emerald-650 group-hover:bg-emerald-100'}`}>
              <AlertTriangle className="h-4.5 w-4.5" />
            </div>
          </div>
          <div className="flex items-baseline space-x-1.5">
            <span className={`text-3xl font-display font-black ${overAllocatedCount > 0 ? 'text-rose-600' : 'text-gray-950'}`}>
              {overAllocatedCount}
            </span>
            <span className="text-xs text-gray-400 font-bold font-mono">of {people.length} active</span>
          </div>
          <div className="mt-3.5">
            <span className={`inline-flex items-center text-[10px] font-bold tracking-wide rounded-full px-2 py-0.5 ${
              overAllocatedCount > 0 ? 'text-rose-700 bg-rose-50 border border-rose-100/60' : 'text-emerald-700 bg-emerald-50 border border-emerald-100/60'
            }`}>
              {overAllocatedCount > 0 ? '⚠️ Workload imbalance' : '✓ Workforce balanced'}
            </span>
          </div>
        </div>
        <div className={`mt-4 pt-2 border-t border-gray-50 flex items-center justify-between text-[10px] font-bold group-hover:underline ${
          overAllocatedCount > 0 ? 'text-rose-600' : 'text-emerald-600'
        }`}>
          <span className="flex items-center gap-1">
            <Sparkles className="h-3 w-3 animate-pulse" />
            Investigate overallocation
          </span>
          <ChevronRight className="h-3.5 w-3.5 transform group-hover:translate-x-0.5 transition" />
        </div>
      </div>

      {/* Staffing Gaps Widget */}
      <div 
        id="stat-gaps" 
        onClick={() => triggerStatsHelp('gaps')}
        className="bg-white p-5 rounded-2xl border border-gray-100 shadow-xs hover:border-amber-200 hover:shadow-xs transition duration-200 cursor-pointer group flex flex-col justify-between"
        title="Click to explore and match candidates for project gaps with AI"
      >
        <div>
          <div className="flex items-center justify-between mb-3">
            <span className="text-xs font-bold text-gray-400 uppercase tracking-widest font-mono">Understaffed Projects</span>
            <div className={`p-2 rounded-xl transition ${projectGapsCount > 0 ? 'bg-amber-50 text-amber-600 group-hover:bg-amber-100' : 'bg-emerald-50 text-emerald-600'}`}>
              <FolderKanban className="h-4.5 w-4.5" />
            </div>
          </div>
          <div className="flex items-baseline space-x-1.5">
            <span className={`text-3xl font-display font-black ${projectGapsCount > 0 ? 'text-amber-600' : 'text-gray-900'}`}>
              {projectGapsCount}
            </span>
            <span className="text-xs text-gray-400 font-bold font-mono">of {projects.length} initiatives</span>
          </div>
          <div className="mt-3.5">
            <span className={`inline-flex items-center text-[10px] font-bold tracking-wide rounded-full px-2 py-0.5 ${
              projectGapsCount > 0 ? 'text-amber-700 bg-amber-50 border border-amber-100' : 'text-emerald-700 bg-emerald-50'
            }`}>
              {projectGapsCount > 0 ? `Needs resource matching` : '✓ All competencies covered'}
            </span>
          </div>
        </div>
        <div className="mt-4 pt-2 border-t border-gray-50 flex items-center justify-between text-[10px] font-bold text-amber-600 group-hover:text-amber-700">
          <span className="flex items-center gap-1">
            <Sparkles className="h-3 w-3 animate-pulse" />
            Matchmaker candidates
          </span>
          <ChevronRight className="h-3.5 w-3.5 transform group-hover:translate-x-0.5 transition" />
        </div>
      </div>

      {/* Upcoming PTO Widget */}
      <div 
        id="stat-pto" 
        onClick={() => triggerStatsHelp('pto')}
        className="bg-white p-5 rounded-2xl border border-gray-100 shadow-xs hover:border-sky-200 hover:shadow-xs transition duration-200 cursor-pointer group flex flex-col justify-between"
        title="Click to analyze planned employee vacations impact with AI"
      >
        <div>
          <div className="flex items-center justify-between mb-3">
            <span className="text-xs font-bold text-gray-400 uppercase tracking-widest font-mono">Planned Time-Off (PTO)</span>
            <div className="p-2 bg-sky-50 text-sky-600 rounded-xl group-hover:bg-sky-100 transition">
              <CalendarClock className="h-4.5 w-4.5" />
            </div>
          </div>
          <div className="flex items-baseline space-x-1.5">
            <span className="text-3xl font-display font-black text-gray-950">{timeOffCount}</span>
            <span className="text-xs text-gray-400 font-bold font-mono">intervals logged</span>
          </div>
          <div className="mt-3.5">
            <span className="inline-flex items-center text-[10px] font-bold tracking-wide text-sky-700 bg-sky-50 border border-sky-100 rounded-full px-2 py-0.5">
              🌴 Holiday schedules active
            </span>
          </div>
        </div>
        <div className="mt-4 pt-2 border-t border-gray-50 flex items-center justify-between text-[10px] font-bold text-sky-600 group-hover:text-sky-700">
          <span className="flex items-center gap-1">
            <Sparkles className="h-3 w-3 animate-pulse" />
            Track holiday overlaps
          </span>
          <ChevronRight className="h-3.5 w-3.5 transform group-hover:translate-x-0.5 transition" />
        </div>
      </div>

    </div>
  );
}
