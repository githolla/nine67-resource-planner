/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

import React, { useState } from 'react';
import { Person, TimeOff } from '../types';
import { Users, Plus, Trash2, Edit2, Check, X, Calendar, Umbrella, Award } from 'lucide-react';

interface PeopleListProps {
  people: Person[];
  onAddPerson: (person: Person) => void;
  onUpdatePerson: (person: Person) => void;
  onRemovePerson: (id: string) => void;
}

export default function PeopleList({ people, onAddPerson, onUpdatePerson, onRemovePerson }: PeopleListProps) {
  // Editing state
  const [editingId, setEditingId] = useState<string | null>(null);
  const [editForm, setEditForm] = useState<Partial<Person>>({});
  
  // Adding state
  const [isAdding, setIsAdding] = useState(false);
  const [newPerson, setNewPerson] = useState<Partial<Person>>({
    name: '',
    role: '',
    team: 'Engineering',
    skills: [],
    capacityPercent: 100,
    timeOff: []
  });

  // Individual states for editing skills
  const [skillsInput, setSkillsInput] = useState('');
  // Vacation add states
  const [newVacation, setNewVacation] = useState({ description: '', startDate: '', endDate: '' });

  const startEdit = (p: Person) => {
    setEditingId(p.id);
    setEditForm({ ...p });
    setSkillsInput(p.skills.join(', '));
  };

  const cancelEdit = () => {
    setEditingId(null);
    setEditForm({});
  };

  const saveEdit = () => {
    if (!editForm.name || !editForm.role) return;
    const finalSkills = skillsInput.split(',').map(s => s.trim()).filter(s => s.length > 0);
    const updated: Person = {
      ...(editForm as Person),
      skills: finalSkills
    };
    onUpdatePerson(updated);
    setEditingId(null);
    setEditForm({});
  };

  const handleAdd = () => {
    if (!newPerson.name || !newPerson.role) return;
    const finalSkills = skillsInput.split(',').map(s => s.trim()).filter(s => s.length > 0);
    const created: Person = {
      id: `p-${Date.now()}`,
      name: newPerson.name,
      role: newPerson.role,
      team: newPerson.team || 'Engineering',
      skills: finalSkills,
      capacityPercent: Number(newPerson.capacityPercent) || 100,
      timeOff: newPerson.timeOff || []
    };
    onAddPerson(created);
    setIsAdding(false);
    setNewPerson({
      name: '',
      role: '',
      team: 'Engineering',
      skills: [],
      capacityPercent: 100,
      timeOff: []
    });
    setSkillsInput('');
  };

  const handleAddVacation = (personId: string, isEditingForm: boolean) => {
    if (!newVacation.description || !newVacation.startDate || !newVacation.endDate) return;
    
    const createdVacation: TimeOff = {
      id: `to-${Date.now()}`,
      description: newVacation.description,
      startDate: newVacation.startDate,
      endDate: newVacation.endDate
    };

    if (isEditingForm) {
      const updatedTimeOff = [...(editForm.timeOff || []), createdVacation];
      setEditForm({ ...editForm, timeOff: updatedTimeOff });
    } else {
      const updatedTimeOff = [...(newPerson.timeOff || []), createdVacation];
      setNewPerson({ ...newPerson, timeOff: updatedTimeOff });
    }

    setNewVacation({ description: '', startDate: '', endDate: '' });
  };

  const handleRemoveVacation = (isEditingForm: boolean, vacationId: string) => {
    if (isEditingForm) {
      const filtered = (editForm.timeOff || []).filter(to => to.id !== vacationId);
      setEditForm({ ...editForm, timeOff: filtered });
    } else {
      const filtered = (newPerson.timeOff || []).filter(to => to.id !== vacationId);
      setNewPerson({ ...newPerson, timeOff: filtered });
    }
  };

  return (
    <div id="people-panel" className="bg-white rounded-2xl border border-gray-100 shadow-xs p-6 mb-6">
      <div className="flex items-center justify-between mb-4 pb-4 border-b border-gray-100">
        <h2 className="text-lg font-display font-bold text-gray-950 flex items-center gap-2">
          <Users className="h-5 w-5 text-indigo-600" />
          Resource Directory & Competency
        </h2>
        {!isAdding && (
          <button
            onClick={() => {
              setIsAdding(true);
              setSkillsInput('');
            }}
            className="inline-flex items-center gap-1 px-3 py-1.5 bg-indigo-600 hover:bg-indigo-700 text-white rounded-lg text-xs font-semibold shadow-xs transition"
          >
            <Plus className="h-4 w-4" /> Add Team Member
          </button>
        )}
      </div>

      {/* ADD NEW MEMBER FORM PANEL */}
      {isAdding && (
        <div className="bg-slate-50 border border-slate-200/60 rounded-xl p-5 mb-5 space-y-4">
          <h3 className="text-sm font-semibold text-slate-800">New Resource Profile</h3>
          <div className="grid grid-cols-1 md:grid-cols-4 gap-4">
            <div>
              <label className="block text-[10px] font-bold text-slate-500 uppercase tracking-widest mb-1">Full Name</label>
              <input
                type="text"
                value={newPerson.name || ''}
                onChange={(e) => setNewPerson({ ...newPerson, name: e.target.value })}
                placeholder="Jane Cooper"
                className="w-full text-xs border border-gray-200 rounded-lg p-2 bg-white focus:outline-indigo-500"
              />
            </div>
            <div>
              <label className="block text-[10px] font-bold text-slate-500 uppercase tracking-widest mb-1">Professional Role</label>
              <input
                type="text"
                value={newPerson.role || ''}
                onChange={(e) => setNewPerson({ ...newPerson, role: e.target.value })}
                placeholder="Senior React Engineer"
                className="w-full text-xs border border-gray-200 rounded-lg p-2 bg-white focus:outline-indigo-500"
              />
            </div>
            <div>
              <label className="block text-[10px] font-bold text-slate-500 uppercase tracking-widest mb-1">Business Team</label>
              <select
                value={newPerson.team || 'Engineering'}
                onChange={(e) => setNewPerson({ ...newPerson, team: e.target.value })}
                className="w-full text-xs border border-gray-200 rounded-lg p-2 bg-white focus:outline-indigo-500"
              >
                <option value="Engineering">Engineering</option>
                <option value="Design">Design</option>
                <option value="Product">Product</option>
                <option value="QA">QA</option>
                <option value="Marketing">Marketing</option>
              </select>
            </div>
            <div>
              <label className="block text-[10px] font-bold text-slate-500 uppercase tracking-widest mb-1">Weekly Capacity (%)</label>
              <input
                type="number"
                min="10"
                max="200"
                value={newPerson.capacityPercent || 100}
                onChange={(e) => setNewPerson({ ...newPerson, capacityPercent: Number(e.target.value) })}
                className="w-full text-xs border border-gray-200 rounded-lg p-2 bg-white focus:outline-indigo-500"
              />
            </div>
          </div>

          <div>
            <label className="block text-[10px] font-bold text-slate-500 uppercase tracking-widest mb-1">Skills (comma separated, e.g., React, Python)</label>
            <input
              type="text"
              value={skillsInput}
              onChange={(e) => setSkillsInput(e.target.value)}
              placeholder="React, TypeScript, SQL, System Design"
              className="w-full text-xs border border-gray-200 rounded-lg p-2 bg-white focus:outline-indigo-500"
            />
          </div>

          {/* VACATION FORMS IN CREATION */}
          <div className="border-t border-slate-200 pt-3 mt-3">
            <h4 className="text-[11px] font-bold text-slate-600 uppercase tracking-wider mb-2 flex items-center gap-1">
              <Umbrella className="h-3.5 w-3.5 text-amber-500" />
              Pre-plan Time Off / Recesses
            </h4>
            
            {(newPerson.timeOff || []).length > 0 && (
              <div className="flex flex-wrap gap-2 mb-3">
                {(newPerson.timeOff || []).map(to => (
                  <div key={to.id} className="flex items-center gap-1.5 px-2 py-1 bg-amber-50 text-amber-800 border border-amber-200 rounded-lg text-xs font-mono">
                    <span>{to.description} ({to.startDate} to {to.endDate})</span>
                    <button type="button" onClick={() => handleRemoveVacation(false, to.id)} className="text-amber-500 hover:text-amber-800">
                      <X className="h-3.5 w-3.5" />
                    </button>
                  </div>
                ))}
              </div>
            )}

            <div className="grid grid-cols-1 md:grid-cols-4 gap-2 items-end">
              <div>
                <input
                  type="text"
                  placeholder="Vacation description..."
                  value={newVacation.description}
                  onChange={(e) => setNewVacation({ ...newVacation, description: e.target.value })}
                  className="w-full text-xs border border-gray-100 rounded-lg p-1.5 bg-white focus:outline-indigo-500"
                />
              </div>
              <div>
                <input
                  type="date"
                  value={newVacation.startDate}
                  onChange={(e) => setNewVacation({ ...newVacation, startDate: e.target.value })}
                  className="w-full text-xs border border-gray-100 rounded-lg p-1.5 bg-white focus:outline-indigo-500"
                />
              </div>
              <div>
                <input
                  type="date"
                  value={newVacation.endDate}
                  onChange={(e) => setNewVacation({ ...newVacation, endDate: e.target.value })}
                  className="w-full text-xs border border-gray-100 rounded-lg p-1.5 bg-white focus:outline-indigo-500"
                />
              </div>
              <button
                type="button"
                onClick={() => handleAddVacation("", false)}
                className="px-3 py-1.5 bg-amber-500 hover:bg-amber-600 text-white rounded-lg text-xs font-semibold shadow-xs"
              >
                Log Vacation Block
              </button>
            </div>
          </div>

          <div className="flex justify-end gap-2 pt-3 border-t border-slate-200/60">
            <button
              onClick={() => setIsAdding(false)}
              className="px-3 py-1.5 bg-white border border-gray-200 text-gray-700 hover:bg-gray-50 rounded-lg text-xs font-bold transition"
            >
              Cancel
            </button>
            <button
              onClick={handleAdd}
              className="px-3 py-1.5 bg-indigo-600 hover:bg-indigo-700 text-white rounded-lg text-xs font-bold shadow-xs transition"
            >
              Save Resource
            </button>
          </div>
        </div>
      )}

      {/* LIST OF CURRENT TEAM MEMBERS FIELDS */}
      <div className="grid grid-cols-1 lg:grid-cols-2 gap-4">
        {people.map(p => {
          const isEditing = editingId === p.id;
          return (
            <div
              key={p.id}
              id={`person-card-${p.id}`}
              className={`border rounded-xl p-4 transition ${
                isEditing ? 'border-indigo-400 bg-indigo-50/10 shadow-xs' : 'border-gray-100 hover:border-gray-200 hover:shadow-xs'
              }`}
            >
              {isEditing ? (
                // EDITING MODE FORM
                <div className="space-y-3">
                  <div className="flex justify-between items-center pb-2 border-b border-gray-100">
                    <h4 className="text-xs font-bold text-indigo-700 uppercase tracking-widest font-mono">Modifying Profile</h4>
                    <div className="flex items-center gap-1">
                      <button onClick={saveEdit} className="p-1 px-2.5 bg-indigo-700 text-white rounded-lg text-xs font-bold hover:bg-indigo-800 flex items-center gap-1 transition">
                        <Check className="h-3.5 w-3.5" /> Save
                      </button>
                      <button onClick={cancelEdit} className="p-1 px-2 bg-white border border-gray-200 text-gray-500 rounded-lg text-xs font-bold hover:bg-gray-50 transition">
                        <X className="h-3.5 w-3.5" />
                      </button>
                    </div>
                  </div>

                  <div className="grid grid-cols-2 gap-2">
                    <div>
                      <label className="block text-[9px] font-bold text-gray-400 uppercase tracking-widest">Name</label>
                      <input
                        type="text"
                        value={editForm.name || ''}
                        onChange={(e) => setEditForm({ ...editForm, name: e.target.value })}
                        className="w-full text-xs p-1.5 border border-gray-200 rounded bg-white focus:outline-indigo-500 font-medium"
                      />
                    </div>
                    <div>
                      <label className="block text-[9px] font-bold text-gray-400 uppercase tracking-widest">Role</label>
                      <input
                        type="text"
                        value={editForm.role || ''}
                        onChange={(e) => setEditForm({ ...editForm, role: e.target.value })}
                        className="w-full text-xs p-1.5 border border-gray-200 rounded bg-white focus:outline-indigo-500"
                      />
                    </div>
                  </div>

                  <div className="grid grid-cols-2 gap-2">
                    <div>
                      <label className="block text-[9px] font-bold text-gray-400 uppercase tracking-widest">Team</label>
                      <select
                        value={editForm.team || 'Engineering'}
                        onChange={(e) => setEditForm({ ...editForm, team: e.target.value })}
                        className="w-full text-xs p-1.5 border border-gray-200 rounded bg-white focus:outline-indigo-500"
                      >
                        <option value="Engineering">Engineering</option>
                        <option value="Design">Design</option>
                        <option value="Product">Product</option>
                        <option value="QA">QA</option>
                        <option value="Marketing">Marketing</option>
                      </select>
                    </div>
                    <div>
                      <label className="block text-[9px] font-bold text-gray-400 uppercase tracking-widest">Capacity Limit %</label>
                      <input
                        type="number"
                        value={editForm.capacityPercent || 100}
                        onChange={(e) => setEditForm({ ...editForm, capacityPercent: Number(e.target.value) })}
                        className="w-full text-xs p-1.5 border border-gray-200 rounded bg-white focus:outline-indigo-500"
                      />
                    </div>
                  </div>

                  <div>
                    <label className="block text-[9px] font-bold text-gray-400 uppercase tracking-widest">Skills (comma separated)</label>
                    <input
                      type="text"
                      value={skillsInput}
                      onChange={(e) => setSkillsInput(e.target.value)}
                      className="w-full text-xs p-1.5 border border-gray-200 rounded bg-white focus:outline-indigo-500"
                    />
                  </div>

                  {/* EDIT PATIENT TIME OFF ENTRIES */}
                  <div className="border-t border-gray-100 pt-2">
                    <h5 className="text-[10px] font-bold text-amber-700 uppercase flex items-center gap-1.5">
                      <Umbrella className="h-3 w-3" /> Time Off Vacations
                    </h5>
                    
                    {(editForm.timeOff || []).length > 0 && (
                      <div className="flex flex-wrap gap-1.5 my-2">
                        {(editForm.timeOff || []).map(to => (
                          <div key={to.id} className="flex items-center gap-1 px-1.5 py-0.5 bg-amber-50 text-amber-900 border border-amber-100 rounded text-[10px] font-mono">
                            <span>{to.description} ({to.startDate} to {to.endDate})</span>
                            <button type="button" onClick={() => handleRemoveVacation(true, to.id)} className="text-amber-500 hover:text-amber-700">
                              <X className="h-2.5 w-2.5" />
                            </button>
                          </div>
                        ))}
                      </div>
                    )}

                    <div className="grid grid-cols-3 gap-1 items-end mt-2">
                      <input
                        type="text"
                        placeholder="New Event Desc"
                        value={newVacation.description}
                        onChange={(e) => setNewVacation({ ...newVacation, description: e.target.value })}
                        className="text-[10px] border border-gray-200 rounded p-1 bg-white"
                      />
                      <input
                        type="date"
                        value={newVacation.startDate}
                        onChange={(e) => setNewVacation({ ...newVacation, startDate: e.target.value })}
                        className="text-[10px] border border-gray-200 rounded p-1 bg-white"
                      />
                      <input
                        type="date"
                        value={newVacation.endDate}
                        onChange={(e) => setNewVacation({ ...newVacation, endDate: e.target.value })}
                        className="text-[10px] border border-gray-200 rounded p-1 bg-white"
                      />
                    </div>
                    <button
                      type="button"
                      onClick={() => handleAddVacation(p.id, true)}
                      className="mt-1.5 px-2 py-1 bg-amber-200/60 hover:bg-amber-300/80 text-amber-800 rounded font-bold text-[10px] transition"
                    >
                      + Log PTO Block
                    </button>
                  </div>
                </div>
              ) : (
                // STANDARD DISPLAY CARD
                <div className="flex flex-col h-full justify-between">
                  <div>
                    <div className="flex items-start justify-between">
                      <div className="flex items-center gap-2.5">
                        <div className="w-9 h-9 rounded-full bg-indigo-50 border border-indigo-100 text-indigo-600 font-display font-semibold flex items-center justify-center text-sm">
                          {p.name.split(' ').map(n => n[0]).join('')}
                        </div>
                        <div>
                          <h4 className="text-sm font-semibold text-gray-900">{p.name}</h4>
                          <p className="text-xs text-gray-400 font-mono flex items-center gap-1.5">
                            <span className="bg-slate-100 text-slate-700 px-1 py-0.5 rounded text-[9px] uppercase font-bold">{p.team}</span>
                            <span>{p.role}</span>
                          </p>
                        </div>
                      </div>
                      <div className="flex items-center gap-1">
                        <button
                          onClick={() => startEdit(p)}
                          className="p-1.5 bg-gray-50 text-gray-400 hover:text-indigo-600 hover:bg-indigo-50 rounded-lg transition"
                          title="Edit Resource"
                        >
                          <Edit2 className="h-3.5 w-3.5" />
                        </button>
                        <button
                          onClick={() => onRemovePerson(p.id)}
                          className="p-1.5 bg-gray-50 text-gray-400 hover:text-red-600 hover:bg-red-50 rounded-lg transition"
                          title="Delete Resource Profile"
                        >
                          <Trash2 className="h-3.5 w-3.5" />
                        </button>
                      </div>
                    </div>

                    {/* Capacity Indicator Pill */}
                    <div className="mt-3 flex items-center gap-2">
                      <span className="text-[10px] font-bold text-gray-400 uppercase tracking-widest font-mono">FTE Threshold:</span>
                      <span className={`px-2 py-0.5 rounded-full text-[10px] font-semibold ${
                        p.capacityPercent < 100 ? 'bg-amber-50 text-amber-700' : 'bg-emerald-50 text-emerald-700'
                      }`}>
                        {p.capacityPercent}% Available ({p.capacityPercent * 0.4} hours/week)
                      </span>
                    </div>

                    {/* Competency Technical Skills Row */}
                    <div className="mt-3">
                      <div className="flex items-center gap-1 mb-1">
                        <Award className="h-3.5 w-3.5 text-indigo-400" />
                        <span className="text-[10px] font-bold text-gray-400 uppercase tracking-widest">Competency & Skills</span>
                      </div>
                      <div className="flex flex-wrap gap-1">
                        {p.skills.map((skill, si) => (
                          <span
                            key={si}
                            className="bg-indigo-50/50 text-indigo-700 text-[10px] px-2 py-0.5 border border-indigo-100/30 rounded-md font-medium"
                          >
                            {skill}
                          </span>
                        ))}
                      </div>
                    </div>
                  </div>

                  {/* Time Off vacation dates */}
                  {p.timeOff.length > 0 && (
                    <div className="mt-3 pt-2.5 border-t border-gray-50 flex flex-col justify-end">
                      <div className="text-[10px] text-amber-700 font-bold uppercase tracking-wider mb-1 flex items-center gap-1">
                        <Calendar className="h-3 w-3" /> Blocked Calendar PTO
                      </div>
                      <div className="space-y-1">
                        {p.timeOff.map(to => (
                          <div key={to.id} className="text-[11px] text-gray-500 flex justify-between items-center bg-amber-50/30 px-2 py-1 rounded border border-amber-50">
                            <span className="font-semibold text-amber-900">{to.description}</span>
                            <span className="font-mono text-[10px] text-amber-700">{to.startDate} to {to.endDate}</span>
                          </div>
                        ))}
                      </div>
                    </div>
                  )}
                </div>
              )}
            </div>
          );
        })}
      </div>
    </div>
  );
}
