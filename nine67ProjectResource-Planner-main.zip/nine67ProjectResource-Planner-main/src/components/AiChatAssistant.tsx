/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

import React, { useState, useRef, useEffect } from 'react';
import { Person, Project, Allocation, ChatMessage } from '../types';
import { Sparkles, Send, Bot, RefreshCw, AlertTriangle, CheckCircle2, ChevronRight, FileText, UserCheck, HelpCircle } from 'lucide-react';

interface AiChatAssistantProps {
  people: Person[];
  projects: Project[];
  allocations: Allocation[];
  onAiUpdateState: (
    updatedPeople: Person[],
    updatedProjects: Project[],
    updatedAllocations: Allocation[],
    actionApplied: string | null,
    explanation: string
  ) => void;
  prefilledPrompt?: string | null;
  onClearPrefilledPrompt?: () => void;
}

export default function AiChatAssistant({
  people,
  projects,
  allocations,
  onAiUpdateState,
  prefilledPrompt,
  onClearPrefilledPrompt
}: AiChatAssistantProps) {
  const [messages, setMessages] = useState<ChatMessage[]>([
    {
      id: 'welcome',
      sender: 'assistant',
      text: `Hello! I am your Portfolio Planning Assistant. 👋

I am fully grounded in your team, project, and allocation dataset. Here are some things we can do together:

1. **Answer strategy questions:** Ask me *"Who's free next month?"*, *"What's at risk in Q3?"*, or *"Which projects have skill gaps?"*
2. **Execute changes:** Tell me to *"add Project Helix from Aug to Dec"*, *"assign Sarah Chen to Atlas at 35%"*, or *"move Priya off Project Atlas by 20%."*
3. **Draft briefings:** Use the quick-actions below to generate status summaries with one click!

How can I help optimize your team today?`,
      timestamp: new Date().toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' })
    }
  ]);

  const [inputMessage, setInputMessage] = useState('');
  const [isLoading, setIsLoading] = useState(false);
  const [errorText, setErrorText] = useState<string | null>(null);

  // Selector briefings state
  const [selectedPersonBriefingId, setSelectedPersonBriefingId] = useState('');
  const [selectedProjectBriefingId, setSelectedProjectBriefingId] = useState('');

  const messagesEndRef = useRef<HTMLDivElement>(null);

  // Auto-scroll chat history
  const scrollToBottom = () => {
    messagesEndRef.current?.scrollIntoView({ behavior: 'smooth' });
  };

  useEffect(() => {
    scrollToBottom();
  }, [messages, isLoading]);

  // Handle message sending to backend Express service
  const handleSendMessage = async (customPrompt?: string) => {
    const prompt = (customPrompt || inputMessage).trim();
    if (!prompt) return;

    if (!customPrompt) {
      setInputMessage('');
    }

    // Add user message to history
    const userMsg: ChatMessage = {
      id: `msg-${Date.now()}-user`,
      sender: 'user',
      text: prompt,
      timestamp: new Date().toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' })
    };
    setMessages(prev => [...prev, userMsg]);
    setIsLoading(true);
    setErrorText(null);

    try {
      const response = await fetch('/api/chat', {
        method: 'POST',
        headers: {
          'Content-Type': 'application/json'
        },
        body: JSON.stringify({
          message: prompt,
          people,
          projects,
          allocations
        })
      });

      if (!response.ok) {
        throw new Error(`Server returned error status ${response.status}`);
      }

      const data = await response.json();

      // Check if server gave a warning or errored
      if (data.error && !data.reply) {
        throw new Error(data.error);
      }

      // Append AI response
      const assistantMsg: ChatMessage = {
        id: `msg-${Date.now()}-ai`,
        sender: 'assistant',
        text: data.reply || "I've processed your request but didn't receive a detailed explanation.",
        timestamp: new Date().toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' }),
        aiAction: data.actionApplied || undefined
      };

      setMessages(prev => [...prev, assistantMsg]);

      // If an action was applied and updated arrays were received, invoke parent sync update
      if (data.actionApplied && (data.updatedPeople || data.updatedProjects || data.updatedAllocations)) {
        onAiUpdateState(
          data.updatedPeople || people,
          data.updatedProjects || projects,
          data.updatedAllocations || allocations,
          data.actionApplied,
          data.reply
        );
      }

    } catch (e: any) {
      console.error("AI Assistant connection error:", e);
      setErrorText("Failed to query Gemini. Please confirm that your GEMINI_API_KEY is configured in Settings > Secrets or try again.");
      
      const errorMsg: ChatMessage = {
        id: `msg-${Date.now()}-err`,
        sender: 'assistant',
        text: `Sorry! I had trouble reaching the Gemini service. 

**Diagnostic Details:**
${e.message || 'Unknown network error. Check Express console stacktrace.'}

*Please note: You can still make all your planning changes manually using the directory or allocation tools below!*`,
        timestamp: new Date().toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' })
      };
      setMessages(prev => [...prev, errorMsg]);
    } finally {
      setIsLoading(false);
    }
  };

  // Quick command helpers
  const handleQuickSummary = (type: 'health' | 'status' | 'matching') => {
    let text = '';
    if (type === 'health') {
      text = "Run a comprehensive portfolio health check. Summarize overall capacity vs commitments, list over-allocated people, identify understaffed projects, and suggest immediate priorities for corrective actions.";
    } else if (type === 'status') {
      text = "Generate a polished, professional, the-point 'Weekly Portfolio Status Update' designed for senior leadership. Organize it with sections for Executive Summary, Staffing Gaps/Understaffed projects, Resource Constraint Risks, and Recommendations.";
    } else if (type === 'matching') {
      text = "Analyze all project staffing gaps and suggest smart allocation matchmaking. For every project missing skills, look through our team directory for who has the skills, has spare capacity % in their timeline, hasn't been over-allocated, and explain why they make a perfect fit.";
    }
    handleSendMessage(text);
  };

  const handlePersonBriefing = (personId: string) => {
    if (!personId) return;
    const p = people.find(item => item.id === personId);
    if (!p) return;
    handleSendMessage(`Provide a compact resource briefing for ${p.name}. Detail their current total allocation, which projects they are staffed on, dates of involvement, any overlapping over-allocation, list of expertise, and scheduled PTO holidays.`);
    setSelectedPersonBriefingId('');
  };

  const handleProjectBriefing = (projectId: string) => {
    if (!projectId) return;
    const proj = projects.find(item => item.id === projectId);
    if (!proj) return;
    handleSendMessage(`Provide a comprehensive staffing and competency briefing for ${proj.name}. Analyze whether they have all required skills, who is staffed at what %, details of any staffing gaps, how project priority (${proj.priority}) affects scheduling choices, and risk mitigations.`);
    setSelectedProjectBriefingId('');
  };

  useEffect(() => {
    if (prefilledPrompt) {
      handleSendMessage(prefilledPrompt);
      if (onClearPrefilledPrompt) {
        onClearPrefilledPrompt();
      }
    }
  }, [prefilledPrompt]);

  return (
    <div id="ai-assistant-card" className="bg-slate-900 text-white rounded-2xl shadow-xl flex flex-col h-[650px] relative overflow-hidden border border-slate-800">
      
      {/* HEADER SECTION */}
      <div className="bg-slate-950 p-4 border-b border-slate-800 flex items-center justify-between">
        <div className="flex items-center gap-2.5">
          <div className="p-2 bg-indigo-600 text-white rounded-xl shadow-md shadow-indigo-900/35">
            <Sparkles className="h-5 w-5 animate-pulse" />
          </div>
          <div>
            <h2 className="text-sm font-display font-bold tracking-tight">Built-In AI Portfolio Analyst</h2>
            <div className="flex items-center gap-1.5 mt-0.5">
              <span className="w-1.5 h-1.5 bg-emerald-500 rounded-full inline-block animate-ping"></span>
              <span className="text-[10px] text-zinc-400 font-medium">Gemini 3.5-Flash Active (Server Grounded)</span>
            </div>
          </div>
        </div>
        <button
          onClick={() => {
            setMessages(prev => [
              {
                id: `msg-${Date.now()}`,
                sender: 'assistant',
                text: "Conversation thread restarted. Ask me a question or run an analysis about your current resource database!",
                timestamp: new Date().toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' })
              }
            ]);
          }}
          className="p-1 px-2.5 border border-slate-800 text-slate-400 hover:text-white rounded-lg text-xs font-semibold hover:bg-slate-850 transition"
          title="Clear History"
        >
          Restart Chat
        </button>
      </div>

      {/* QUICK INSIGHTS / REPORTING ACTIONS BAR */}
      <div className="bg-slate-925 p-3 border-b border-slate-800/80 grid grid-cols-1 md:grid-cols-3 gap-2">
        <button
          onClick={() => handleQuickSummary('health')}
          disabled={isLoading}
          className="flex items-center gap-1.5 justify-center py-2 px-3 border border-slate-800 hover:border-indigo-500/50 hover:bg-indigo-950/20 rounded-xl text-left text-xs font-semibold text-slate-300 hover:text-white transition cursor-pointer"
        >
          <Bot className="h-4 w-4 text-indigo-400 shrink-0" />
          <span>Portfolio Health Check</span>
        </button>
        
        <button
          onClick={() => handleQuickSummary('status')}
          disabled={isLoading}
          className="flex items-center gap-1.5 justify-center py-2 px-3 border border-slate-800 hover:border-emerald-500/50 hover:bg-emerald-950/20 rounded-xl text-left text-xs font-semibold text-slate-300 hover:text-white transition cursor-pointer"
        >
          <FileText className="h-4 w-4 text-emerald-400 shrink-0" />
          <span>Weekly Leadership update</span>
        </button>

        <button
          onClick={() => handleQuickSummary('matching')}
          disabled={isLoading}
          className="flex items-center gap-1.5 justify-center py-2 px-3 border border-slate-800 hover:border-pink-500/50 hover:bg-pink-950/20 rounded-xl text-left text-xs font-semibold text-slate-300 hover:text-white transition cursor-pointer"
        >
          <UserCheck className="h-4 w-4 text-pink-400 shrink-0" />
          <span>Gap Staffing Suggestions</span>
        </button>
      </div>

      {/* DETAILED DROPDOWNS FOR PEOPLE & PROJECTS SUMMARY INJECTIONS */}
      <div className="bg-slate-900/60 px-4 py-2.5 border-b border-slate-800/60 flex flex-col sm:flex-row gap-3 items-center justify-between">
        <div id="briefing-picker-person" className="flex items-center gap-1.5 w-full">
          <span className="text-[10px] font-bold text-slate-400 uppercase tracking-widest font-mono">Person Briefing:</span>
          <select
            value={selectedPersonBriefingId}
            onChange={(e) => {
              setSelectedPersonBriefingId(e.target.value);
              handlePersonBriefing(e.target.value);
            }}
            disabled={isLoading}
            className="flex-1 text-[11px] bg-slate-950 text-slate-100 border border-slate-800 rounded-lg p-1 w-full focus:outline-none focus:ring-1 focus:ring-indigo-500"
          >
            <option value="">Select a professional...</option>
            {people.map(p => (
              <option key={p.id} value={p.id}>{p.name} ({p.team})</option>
            ))}
          </select>
        </div>

        <div id="briefing-picker-project" className="flex items-center gap-1.5 w-full">
          <span className="text-[10px] font-bold text-slate-400 uppercase tracking-widest font-mono">Project Briefing:</span>
          <select
            value={selectedProjectBriefingId}
            onChange={(e) => {
              setSelectedProjectBriefingId(e.target.value);
              handleProjectBriefing(e.target.value);
            }}
            disabled={isLoading}
            className="flex-1 text-[11px] bg-slate-950 text-slate-100 border border-slate-800 rounded-lg p-1 w-full focus:outline-none focus:ring-1 focus:ring-indigo-500"
          >
            <option value="">Select an initiative...</option>
            {projects.map(pr => (
              <option key={pr.id} value={pr.id}>{pr.name}</option>
            ))}
          </select>
        </div>
      </div>

      {/* CONVERSATION WRAPPER CONTAINER */}
      <div className="flex-1 overflow-y-auto p-4 space-y-4 bg-slate-925 selection:bg-slate-800">
        {messages.map(msg => {
          const isAi = msg.sender === 'assistant';
          return (
            <div
              key={msg.id}
              className={`flex flex-col ${isAi ? 'items-start' : 'items-end'}`}
            >
              <div className="flex items-baseline space-x-2 mb-1">
                <span className="text-[10px] text-slate-400 font-bold tracking-widest uppercase font-mono">
                  {isAi ? 'AI Portfolio Analyst' : 'You (Planner)'}
                </span>
                <span className="text-[9px] text-slate-500 font-mono">{msg.timestamp}</span>
              </div>
              <div
                className={`p-3.5 rounded-2xl max-w-[90%] text-sm leading-relaxed whitespace-pre-wrap select-text ${
                  isAi 
                    ? 'bg-slate-850 text-slate-100 border border-slate-800/80 rounded-tl-none font-sans' 
                    : 'bg-indigo-600 text-white rounded-tr-none font-sans font-medium'
                }`}
              >
                {/* Custom markdown formatter block to look highly readable inside the white-slate layout */}
                {msg.text}

                {/* If AI executed an operation update on state */}
                {msg.aiAction && (
                  <div className="mt-3.5 pt-2.5 border-t border-slate-700/60 text-xs text-indigo-400 flex items-center gap-1.5 font-semibold">
                    <CheckCircle2 className="h-4 w-4 text-emerald-400 shrink-0" />
                    <span>Applied Change: &ldquo;{msg.aiAction}&rdquo;</span>
                  </div>
                )}
              </div>
            </div>
          );
        })}

        {/* LOADING REASSURANCES SKELETON */}
        {isLoading && (
          <div className="flex flex-col items-start">
            <div className="flex items-center gap-2 mb-1">
              <span className="text-[10px] text-slate-400 font-bold tracking-widest font-mono">AI THINKING...</span>
              <RefreshCw className="h-3 w-3 text-indigo-400 animate-spin" />
            </div>
            <div className="p-4 bg-slate-850/60 text-slate-400 border border-slate-850 text-xs rounded-2xl rounded-tl-none flex flex-col gap-1 w-64 animate-pulse">
              <span className="font-semibold text-slate-300">Evaluating capacity indices...</span>
              <span className="text-[10px] text-slate-500">Checking timeline overlaps for team calendars</span>
            </div>
          </div>
        )}

        <div ref={messagesEndRef} />
      </div>

      {/* Interactive Quick-Scenarios chips */}
      <div className="bg-slate-950 border-t border-slate-850 px-4 py-2.5 flex flex-wrap items-center gap-1.5 select-none shrink-0 border-b border-slate-900/60">
        <span className="text-[9px] font-bold text-slate-500 uppercase tracking-widest font-mono">Suggested Quick-Actions:</span>
        <button
          type="button"
          disabled={isLoading}
          onClick={() => handleSendMessage("Move Priya off Project Atlas by 20%")}
          className="text-[10px] font-semibold bg-slate-905 hover:bg-slate-850 hover:text-white border border-slate-800 text-slate-300 px-2 py-1 rounded-lg transition-all active:scale-95 duration-100 cursor-pointer"
        >
          Move Priya off Atlas (20%)
        </button>
        <button
          type="button"
          disabled={isLoading}
          onClick={() => handleSendMessage("Assign Sarah Chen to Project Atlas at 35%")}
          className="text-[10px] font-semibold bg-slate-905 hover:bg-slate-850 hover:text-white border border-slate-800 text-slate-300 px-2 py-1 rounded-lg transition-all active:scale-95 duration-100 cursor-pointer"
        >
          Assign Sarah 35% to Atlas
        </button>
        <button
          type="button"
          disabled={isLoading}
          onClick={() => handleSendMessage("Run a smart matchmaking analysis on our project competency gaps")}
          className="text-[10px] font-semibold bg-indigo-950 hover:bg-indigo-900 text-indigo-300 border border-indigo-900/40 px-2.5 py-1 rounded-lg transition-all active:scale-95 duration-100 cursor-pointer flex items-center gap-1"
        >
          <Sparkles className="h-2.5 w-2.5 text-indigo-400" /> Gap Matchmaker
        </button>
      </div>

      {/* CHAT INPUT AREA */}
      <div className="p-4 bg-slate-950 border-t border-slate-800 select-none">
        {errorText && (
          <div className="bg-red-950/40 border border-red-900 text-red-200 text-xs px-3 py-2 rounded-xl mb-3 flex items-start gap-2">
            <AlertTriangle className="h-4 w-4 text-red-400 shrink-0 mt-0.5" />
            <p>{errorText}</p>
          </div>
        )}
        <form
          onSubmit={(e) => {
            e.preventDefault();
            handleSendMessage();
          }}
          className="flex items-center gap-2"
        >
          <input
            type="text"
            value={inputMessage}
            onChange={(e) => setInputMessage(e.target.value)}
            disabled={isLoading}
            placeholder={
              isLoading 
                ? "Connecting with assistant..." 
                : "Ask matching questions or request scenario updates in plain English..."
            }
            className="flex-1 bg-slate-900 border border-slate-800 rounded-xl px-4 py-3 text-sm text-white placeholder-slate-500 focus:outline-none focus:ring-1 focus:ring-indigo-500 disabled:opacity-50"
          />
          <button
            type="submit"
            disabled={isLoading || !inputMessage.trim()}
            className="p-3 bg-indigo-600 text-white rounded-xl hover:bg-indigo-500 transition disabled:opacity-30 disabled:hover:bg-indigo-600"
          >
            <Send className="h-4 w-4" />
          </button>
        </form>
        <p className="text-[10px] text-slate-500 mt-2 text-center">
          Example changes: &ldquo;Move Priya off Atlas by 20%&rdquo; • &ldquo;Add Project Helix starting in August&rdquo;
        </p>
      </div>
    </div>
  );
}
