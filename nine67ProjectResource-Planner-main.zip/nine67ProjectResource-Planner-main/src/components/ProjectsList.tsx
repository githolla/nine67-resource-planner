/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

import React, { useState } from 'react';
import { Project, Person, Allocation } from '../types';
import { FolderKanban, Plus, Trash2, Edit2, Check, X, Tag, UserPlus, Info, CalendarRange, CheckCircle2, AlertTriangle, Sparkles } from 'lucide-react';

interface ProjectsListProps {
  projects: Project[];
  people: Person[];
  allocations: Allocation[];
  onAddProject: (project: Project) => void;
  onUpdateProject: (project: Project) => void;
  onRemoveProject: (id: string) => void;
  onAddAllocation: (allocation: Allocation) => void;
  onRemoveAllocation: (id: string) => void;
  onRequestAiHelp?: (prompt: string) => void;
}

export default function ProjectsList({
  projects,
  people,
  allocations,
  onAddProject,
  onUpdateProject,
  onRemoveProject,
  onAddAllocation,
  onRemoveAllocation,
  onRequestAiHelp
}: ProjectsListProps) {
  // Editing project state
  const [editingId, setEditingId] = useState<string | null>(null);
  const [editForm, setEditForm] = useState<Partial<Project>>({});
  const [skillsInput, setSkillsInput] = useState('');

  // Adding project state
  const [isAdding, setIsAdding] = useState(false);
  const [newProject, setNewProject] = useState<Partial<Project>>({
    name: '',
    description: '',
    startDate: '',
    endDate: '',
    priority: 'Medium',
    requiredSkills: []
  });

  // Allocation fast additions (Inline Staffing modal inside card)
  const [staffingProjId, setStaffingProjId] = useState<string | null>(null);
  const [newAlloc, setNewAlloc] = useState({ personId: '', percentage: 30, startDate: '', endDate: '' });

  const startEdit = (p: Project) => {
    setEditingId(p.id);
    setEditForm({ ...p });
    setSkillsInput(p.requiredSkills.join(', '));
  };

  const cancelEdit = () => {
    setEditingId(null);
    setEditForm({});
  };

  const saveEdit = () => {
    if (!editForm.name || !editForm.startDate || !editForm.endDate) return;
    const finalSkills = skillsInput.split(',').map(s => s.trim()).filter(s => s.length > 0);
    const updated: Project = {
      ...(editForm as Project),
      requiredSkills: finalSkills
    };
    onUpdateProject(updated);
    setEditingId(null);
    setEditForm({});
  };

  const handleCreate = () => {
    if (!newProject.name || !newProject.startDate || !newProject.endDate) return;
    const finalSkills = skillsInput.split(',').map(s => s.trim()).filter(s => s.length > 0);
    const created: Project = {
      id: `proj-${Date.now()}`,
      name: newProject.name,
      description: newProject.description || '',
      startDate: newProject.startDate,
      endDate: newProject.endDate,
      priority: newProject.priority || 'Medium',
      requiredSkills: finalSkills
    };
    onAddProject(created);
    setIsAdding(false);
    setNewProject({
      name: '',
      description: '',
      startDate: '',
      endDate: '',
      priority: 'Medium',
      requiredSkills: []
    });
    setSkillsInput('');
  };

  const handleLogStaffing = (projId: string) => {
    if (!newAlloc.personId || !newAlloc.percentage) return;
    const project = projects.find(p => p.id === projId);
    if (!project) return;

    const created: Allocation = {
      id: `alloc-${Date.now()}`,
      personId: newAlloc.personId,
      projectId: projId,
      percentage: Number(newAlloc.percentage),
      startDate: newAlloc.startDate || project.startDate,
      endDate: newAlloc.endDate || project.endDate
    };

    onAddAllocation(created);
    setStaffingProjId(null);
    setNewAlloc({ personId: '', percentage: 30, startDate: '', endDate: '' });
  };

  // Helper values
  const getPriorityStyle = (priority: string) => {
    switch (priority) {
      case 'Critical':
        return 'bg-rose-50 text-rose-700 border-rose-200';
      case 'High':
        return 'bg-orange-50 text-orange-700 border-orange-200';
      case 'Medium':
        return 'bg-blue-50 text-blue-700 border-blue-200';
      case 'Low':
        default:
        return 'bg-slate-100 text-slate-700 border-slate-200';
    }
  };

  return (
    <div id="projects-panel" className="bg-white rounded-2xl border border-gray-100 shadow-xs p-6 mb-6">
      <div className="flex items-center justify-between mb-4 pb-4 border-b border-gray-100">
        <h2 className="text-lg font-display font-bold text-gray-950 flex items-center gap-2">
          <FolderKanban className="h-5 w-5 text-indigo-600" />
          Active Project Portfolios & Staffing Gaps
        </h2>
        {!isAdding && (
          <button
            onClick={() => {
              setIsAdding(true);
              setSkillsInput('');
            }}
            className="inline-flex items-center gap-1 px-3 py-1.5 bg-indigo-600 hover:bg-indigo-700 text-white rounded-lg text-xs font-semibold shadow-xs transition"
          >
            <Plus className="h-4 w-4" /> Add Project Initiative
          </button>
        )}
      </div>

      {/* CREATE NEW PROJECT INLINE FORM PANEL */}
      {isAdding && (
        <div className="bg-slate-50 border border-slate-200/60 rounded-xl p-5 mb-6 space-y-4">
          <h3 className="text-sm font-semibold text-slate-800">Launch New Project Initiative</h3>
          <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
            <div>
              <label className="block text-[10px] font-bold text-slate-500 uppercase tracking-widest mb-1">Project Name</label>
              <input
                type="text"
                value={newProject.name || ''}
                onChange={(e) => setNewProject({ ...newProject, name: e.target.value })}
                placeholder="Project Helix"
                className="w-full text-xs border border-gray-200 rounded-lg p-2 bg-white focus:outline-indigo-500 font-medium"
              />
            </div>
            <div>
              <label className="block text-[10px] font-bold text-slate-500 uppercase tracking-widest mb-1">Start Date</label>
              <input
                type="date"
                value={newProject.startDate || ''}
                onChange={(e) => setNewProject({ ...newProject, startDate: e.target.value })}
                className="w-full text-xs border border-gray-200 rounded-lg p-2 bg-white focus:outline-indigo-500 font-mono"
              />
            </div>
            <div>
              <label className="block text-[10px] font-bold text-slate-500 uppercase tracking-widest mb-1">End Date</label>
              <input
                type="date"
                value={newProject.endDate || ''}
                onChange={(e) => setNewProject({ ...newProject, endDate: e.target.value })}
                className="w-full text-xs border border-gray-200 rounded-lg p-2 bg-white focus:outline-indigo-500 font-mono"
              />
            </div>
          </div>

          <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
            <div className="md:col-span-2">
              <label className="block text-[10px] font-bold text-slate-500 uppercase tracking-widest mb-1">Initiative Brief / Description</label>
              <input
                type="text"
                value={newProject.description || ''}
                onChange={(e) => setNewProject({ ...newProject, description: e.target.value })}
                placeholder="Enterprise system auditing and cloud fleet deployment feasibility tracking."
                className="w-full text-xs border border-gray-200 rounded-lg p-2 bg-white focus:outline-indigo-500"
              />
            </div>
            <div>
              <label className="block text-[10px] font-bold text-slate-500 uppercase tracking-widest mb-1">Critical Priority Level</label>
              <select
                value={newProject.priority || 'Medium'}
                onChange={(e) => setNewProject({ ...newProject, priority: e.target.value as any })}
                className="w-full text-xs border border-gray-200 rounded-lg p-2 bg-white focus:outline-indigo-500"
              >
                <option value="Critical">🔴 Critical (Gap Fix Priority)</option>
                <option value="High">🟠 High Priority</option>
                <option value="Medium">🔵 Medium Priority</option>
                <option value="Low">⚪ Low Priority</option>
              </select>
            </div>
          </div>

          <div>
            <label className="block text-[10px] font-bold text-slate-500 uppercase tracking-widest mb-1">Competencies & Skills Required (comma separated)</label>
            <input
              type="text"
              value={skillsInput}
              onChange={(e) => setSkillsInput(e.target.value)}
              placeholder="React, Docker, Security, SQL"
              className="w-full text-xs border border-gray-200 rounded-lg p-2 bg-white focus:outline-indigo-500"
            />
          </div>

          <div className="flex justify-end gap-2 pt-3 border-t border-slate-200/60">
            <button
              onClick={() => setIsAdding(false)}
              className="px-3 py-1.5 bg-white border border-gray-200 text-gray-700 hover:bg-gray-50 rounded-lg text-xs font-bold transition"
            >
              Cancel
            </button>
            <button
              onClick={handleCreate}
              className="px-3 py-1.5 bg-indigo-600 hover:bg-indigo-700 text-white rounded-lg text-xs font-bold shadow-xs transition"
            >
              Save Project
            </button>
          </div>
        </div>
      )}

      {/* PROJECT INITIATIVES CARDS GRID */}
      <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
        {projects.map(proj => {
          const isEditing = editingId === proj.id;
          
          // Get allocations assigned to this project
          const projectAllocs = allocations.filter(a => a.projectId === proj.id);
          
          // Fetch staffed employees
          const staffedPeople = projectAllocs.map(alloc => {
            const person = people.find(p => p.id === alloc.personId);
            return {
              allocId: alloc.id,
              percentage: alloc.percentage,
              startDate: alloc.startDate,
              endDate: alloc.endDate,
              person: person
            };
          }).filter(sp => sp.person !== undefined) as { allocId: string; percentage: number; startDate: string; endDate: string; person: Person }[];

          // Accumulate staffed skills
          const staffedSkills = new Set<string>();
          staffedPeople.forEach(sp => {
            sp.person.skills.forEach(s => staffedSkills.add(s));
          });

          // Compute staffing gaps
          const missingSkills = proj.requiredSkills.filter(skill => !staffedSkills.has(skill));

          // Calculate visual progress along timeline (June 3 2026 is today)
          const today = new Date('2026-06-03').getTime();
          const start = new Date(proj.startDate).getTime();
          const end = new Date(proj.endDate).getTime();
          let pctCompleted = 0;
          if (today > start) {
            if (today >= end) {
              pctCompleted = 100;
            } else {
              pctCompleted = Math.round(((today - start) / (end - start)) * 100);
            }
          }

          return (
            <div
              key={proj.id}
              id={`project-card-${proj.id}`}
              className={`border rounded-2xl p-5 flex flex-col justify-between transition ${
                isEditing ? 'border-indigo-400 bg-indigo-50/15' : 'border-gray-100 hover:border-gray-200 hover:shadow-xs'
              }`}
            >
              {isEditing ? (
                // EDIT MODE IN CARD FORM
                <div className="space-y-3">
                  <div className="flex justify-between items-center pb-2 border-b border-gray-100">
                    <span className="text-xs font-bold text-indigo-700 uppercase tracking-widest font-mono">Initiative Configuration</span>
                    <div className="flex gap-1">
                      <button onClick={saveEdit} className="p-1 px-2.5 bg-indigo-700 text-white rounded-lg text-xs font-bold hover:bg-indigo-800 transition">
                        Save
                      </button>
                      <button onClick={cancelEdit} className="p-1 px-2 bg-white border border-gray-200 text-gray-500 rounded-lg text-xs font-bold hover:bg-gray-50 transition">
                        Cancel
                      </button>
                    </div>
                  </div>

                  <div>
                    <label className="block text-[9px] font-bold text-gray-400 uppercase tracking-widest">Project Title</label>
                    <input
                      type="text"
                      className="w-full text-xs border border-gray-200 rounded p-1 text-gray-900 bg-white"
                      value={editForm.name || ''}
                      onChange={(e) => setEditForm({ ...editForm, name: e.target.value })}
                    />
                  </div>

                  <div>
                    <label className="block text-[9px] font-bold text-gray-400 uppercase tracking-widest">Brief / Brief Summary</label>
                    <input
                      type="text"
                      className="w-full text-xs border border-gray-200 rounded p-1 text-gray-900 bg-white"
                      value={editForm.description || ''}
                      onChange={(e) => setEditForm({ ...editForm, description: e.target.value })}
                    />
                  </div>

                  <div className="grid grid-cols-3 gap-2">
                    <div>
                      <label className="block text-[9px] font-bold text-gray-400 uppercase tracking-widest">Start Date</label>
                      <input
                        type="date"
                        className="w-full text-xs border border-gray-200 rounded p-1 text-gray-900 bg-white font-mono"
                        value={editForm.startDate || ''}
                        onChange={(e) => setEditForm({ ...editForm, startDate: e.target.value })}
                      />
                    </div>
                    <div>
                      <label className="block text-[9px] font-bold text-gray-400 uppercase tracking-widest">End Date</label>
                      <input
                        type="date"
                        className="w-full text-xs border border-gray-200 rounded p-1 text-gray-900 bg-white font-mono"
                        value={editForm.endDate || ''}
                        onChange={(e) => setEditForm({ ...editForm, endDate: e.target.value })}
                      />
                    </div>
                    <div>
                      <label className="block text-[9px] font-bold text-gray-400 uppercase tracking-widest">Priority</label>
                      <select
                        className="w-full text-xs border border-gray-200 rounded p-1 text-gray-900 bg-white"
                        value={editForm.priority || 'Medium'}
                        onChange={(e) => setEditForm({ ...editForm, priority: e.target.value as any })}
                      >
                        <option value="Critical">Critical</option>
                        <option value="High">High</option>
                        <option value="Medium">Medium</option>
                        <option value="Low">Low</option>
                      </select>
                    </div>
                  </div>

                  <div>
                    <label className="block text-[9px] font-bold text-gray-400 uppercase tracking-widest">Skills Required (comma separated)</label>
                    <input
                      type="text"
                      className="w-full text-xs border border-gray-200 rounded p-1 text-gray-900 bg-white"
                      value={skillsInput}
                      onChange={(e) => setSkillsInput(e.target.value)}
                    />
                  </div>
                </div>
              ) : (
                // STANDARD CARD DISPLAY
                <div>
                  <div className="flex items-start justify-between mb-2">
                    <div>
                      <span className={`inline-block px-2.5 py-0.5 rounded-full text-[10px] font-bold border ${getPriorityStyle(proj.priority)} mb-1`}>
                        {proj.priority} Priority
                      </span>
                      <h3 className="text-base font-display font-bold text-gray-950">{proj.name}</h3>
                    </div>
                    <div className="flex gap-1">
                      <button
                        onClick={() => startEdit(proj)}
                        className="p-1 text-gray-400 hover:text-indigo-600 rounded-lg hover:bg-gray-50 transition"
                      >
                        <Edit2 className="h-4.5 w-4.5" />
                      </button>
                      <button
                        onClick={() => onRemoveProject(proj.id)}
                        className="p-1 text-gray-400 hover:text-red-600 rounded-lg hover:bg-gray-50 transition"
                      >
                        <Trash2 className="h-4.5 w-4.5" />
                      </button>
                    </div>
                  </div>

                  <p id={`desc-${proj.id}`} className="text-xs text-gray-500 mb-4 line-clamp-2">{proj.description}</p>

                  <div className="flex items-center gap-1 text-[11px] font-mono text-gray-400 mb-3 bg-gray-50 p-2 rounded-lg border border-gray-100">
                    <CalendarRange className="h-3.5 w-3.5 text-gray-500" />
                    <span>{proj.startDate} to {proj.endDate}</span>
                    {pctCompleted > 0 && (
                      <span className="ml-auto font-bold text-slate-500">({pctCompleted}% active)</span>
                    )}
                  </div>

                  {/* ACTIVE TEAM ALLOCATION SEGMENT */}
                  <div className="mb-4">
                    <div className="flex items-center justify-between mb-1.5">
                      <span className="text-[10px] font-bold text-gray-400 uppercase tracking-widest font-mono">Assigned Team Staff ({staffedPeople.length})</span>
                      <button
                        onClick={() => {
                          setStaffingProjId(staffingProjId === proj.id ? null : proj.id);
                          setNewAlloc({ personId: people[0]?.id || '', percentage: 30, startDate: proj.startDate, endDate: proj.endDate });
                        }}
                        className="text-[10px] text-indigo-600 font-bold hover:text-indigo-800 hover:underline flex items-center gap-0.5"
                      >
                        <UserPlus className="h-3 w-3" /> Staff Initiative
                      </button>
                    </div>

                    {staffingProjId === proj.id && (
                      <div className="bg-slate-50 border border-slate-200/50 rounded-xl p-3 my-2 space-y-2">
                        <p className="text-[10px] font-bold text-slate-700">Assign Team Member</p>
                        <div className="grid grid-cols-2 gap-2">
                          <select
                            value={newAlloc.personId}
                            onChange={(e) => setNewAlloc({ ...newAlloc, personId: e.target.value })}
                            className="text-[11px] bg-white border border-gray-200 rounded p-1"
                          >
                            <option value="">Select person...</option>
                            {people.map(p => (
                              <option key={p.id} value={p.id}>{p.name} ({p.role})</option>
                            ))}
                          </select>
                          <input
                            type="number"
                            placeholder="Hours or % FTE"
                            value={newAlloc.percentage}
                            onChange={(e) => setNewAlloc({ ...newAlloc, percentage: Number(e.target.value) })}
                            className="text-[11px] bg-white border border-gray-200 rounded p-1"
                            title="Allocation Percentage"
                          />
                        </div>
                        <div className="flex justify-end gap-1.5 pt-1.5 border-t border-slate-200">
                          <button onClick={() => setStaffingProjId(null)} className="text-[10px] px-2 py-1 bg-white border rounded text-slate-600 hover:bg-slate-50">Cancel</button>
                          <button onClick={() => handleLogStaffing(proj.id)} className="text-[10px] px-2.5 py-1 bg-indigo-600 hover:bg-indigo-700 text-white font-bold rounded">Assign</button>
                        </div>
                      </div>
                    )}

                    {staffedPeople.length === 0 ? (
                      <p className="text-[11px] text-red-500 italic bg-red-50 p-2 border border-red-200 rounded-lg">🚨 No resources staffed on this initiative!</p>
                    ) : (
                      <div className="space-y-1.5 max-h-36 overflow-y-auto pr-1">
                        {staffedPeople.map(sp => (
                          <div key={sp.allocId} className="flex justify-between items-center text-xs bg-slate-50 border border-slate-100 p-2 rounded-xl">
                            <div>
                              <span className="font-semibold text-gray-900">{sp.person.name}</span>
                              <span className="text-gray-400 text-[10px] block">({sp.person.role})</span>
                            </div>
                            <div className="flex items-center gap-2">
                              <span className="font-mono bg-indigo-50 border border-indigo-100 text-indigo-700 px-1.5 py-0.5 rounded font-bold text-[10px]">{sp.percentage}% FTE</span>
                              <button
                                onClick={() => onRemoveAllocation(sp.allocId)}
                                className="text-gray-400 hover:text-red-600 p-1"
                                title="Remove staff allocation"
                              >
                                <X className="h-3 w-3" />
                              </button>
                            </div>
                          </div>
                        ))}
                      </div>
                    )}
                  </div>

                  {/* COMPETENCY AND STAFFING GAP SCOREBOARD */}
                  <div className="mt-4 border-t border-gray-100 pt-3">
                    <span className="text-[10px] font-bold text-gray-400 uppercase tracking-widest font-mono block mb-1.5">Competency Coverage Analysis</span>
                    <div className="space-y-1">
                      {proj.requiredSkills.map((skill, skI) => {
                        const isCovered = staffedSkills.has(skill);
                        return (
                          <div key={skI} className="flex items-center justify-between text-xs py-1">
                            <span className="text-gray-600 font-medium flex items-center gap-1">
                              <Tag className="h-3 w-3 text-indigo-400" />
                              {skill}
                            </span>
                            {isCovered ? (
                              <span className="text-emerald-600 flex items-center gap-1 font-semibold text-[10px] bg-emerald-50 px-2 py-0.5 rounded-full">
                                <CheckCircle2 className="h-3.5 w-3.5" /> Covered
                              </span>
                            ) : (
                              <div className="flex items-center gap-1.5">
                                <span className={`flex items-center gap-1 font-bold text-[10px] px-2 py-0.5 rounded-full ${
                                  proj.priority === 'Critical' ? 'bg-rose-100 text-rose-800 animate-pulse' : 'bg-amber-100 text-amber-800'
                                }`}>
                                  <AlertTriangle className="h-3.5 w-3.5" />
                                  {proj.priority === 'Critical' ? '⚠️ Critical Gap' : 'Gap'}
                                </span>
                                {onRequestAiHelp && (
                                  <button
                                    onClick={() => onRequestAiHelp(`Find candidates with competency in '${skill}' to cover the staffing deficit for Project '${proj.name}'. Look through our team roster for who is available, analyze their timeline capacity, and explain why they are a perfect match.`)}
                                    className="p-1 text-slate-400 hover:text-indigo-600 hover:bg-indigo-50 border border-transparent hover:border-indigo-100 rounded-lg transition"
                                    title={`Ask AI to match a team member with '${skill}'`}
                                  >
                                    <Sparkles className="h-3 w-3 text-indigo-505" />
                                  </button>
                                )}
                              </div>
                            )}
                          </div>
                        );
                      })}
                    </div>

                    {missingSkills.length > 0 && (
                      <div className={`mt-3 p-2.5 rounded-xl border text-[11px] ${
                        proj.priority === 'Critical' 
                          ? 'bg-rose-50 border-rose-150 text-rose-800' 
                          : 'bg-amber-50 border-amber-150 text-amber-800'
                      }`}>
                        <div className="font-bold flex items-center gap-1 mb-0.5">
                          <AlertTriangle className="h-3.5 w-3.5" />
                          {proj.priority === 'Critical' ? 'Critical Priority Alert - At Risk!' : 'Staffing Deficiency'}
                        </div>
                        <p className="leading-snug">
                          {proj.priority === 'Critical' 
                            ? `This project represents a Critical operational priority. Immediate hiring or staffing reallocation is required to cover missing skill: ${missingSkills.join(', ')}.` 
                            : `Consider moving resources with competency in [ ${missingSkills.join(', ')} ] onto this initiative before kickoff.`
                          }
                        </p>
                        {onRequestAiHelp && (
                          <button
                            onClick={() => onRequestAiHelp(`Analyze staffing deficiencies for Project ${proj.name}. Smartly find match candidates for missing skills: "${missingSkills.join(', ')}", calculate optimal allocation percentages, and explain why they make a perfect fit.`)}
                            className={`mt-2 py-1 px-2.5 rounded-lg font-bold text-[10px] flex items-center justify-center gap-1.5 shadow-2xs cursor-pointer border transition-all ${
                              proj.priority === 'Critical' 
                                ? 'bg-rose-600 hover:bg-rose-700 text-white border-rose-700' 
                                : 'bg-amber-600 hover:bg-amber-700 text-white border-amber-700'
                            }`}
                          >
                            <Sparkles className="h-3 w-3 text-white" />
                            Solve staffing alert with AI matchmaker
                          </button>
                        )}
                      </div>
                    )}
                  </div>
                </div>
              )}
            </div>
          );
        })}
      </div>
    </div>
  );
}
