/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

import { Person, Project, Allocation } from './types';

export const INITIAL_PEOPLE: Person[] = [
  {
    id: 'p-priya',
    name: 'Priya Sharma',
    role: 'Lead System Architect',
    team: 'Engineering',
    skills: ['React', 'Node.js', 'System Architecture', 'Security'],
    capacityPercent: 100,
    timeOff: [
      {
        id: 'to-priya-summer',
        description: 'Summer Family Vacation',
        startDate: '2026-08-10',
        endDate: '2026-08-14'
      }
    ]
  },
  {
    id: 'p-alex',
    name: 'Alex Chen',
    role: 'Frontend Developer',
    team: 'Engineering',
    skills: ['React', 'TypeScript', 'Tailwind CSS', 'UI Design'],
    capacityPercent: 100,
    timeOff: []
  },
  {
    id: 'p-sarah',
    name: 'Sarah Jenkins',
    role: 'Backend Engineer',
    team: 'Engineering',
    skills: ['Node.js', 'Python', 'SQL', 'Docker', 'Database Integration'],
    capacityPercent: 100,
    timeOff: [
      {
        id: 'to-sarah-july',
        description: 'Family Leave',
        startDate: '2026-07-01',
        endDate: '2026-07-07'
      }
    ]
  },
  {
    id: 'p-marcus',
    name: 'Marcus Thompson',
    role: 'UX Designer',
    team: 'Design',
    skills: ['Figma', 'UI Design', 'User Research', 'Wireframing'],
    capacityPercent: 100,
    timeOff: [
      {
        id: 'to-marcus-fall',
        description: 'Annual Checkup & Recharge',
        startDate: '2026-09-21',
        endDate: '2026-09-25'
      }
    ]
  },
  {
    id: 'p-elena',
    name: 'Elena Rostova',
    role: 'Product Manager',
    team: 'Product',
    skills: ['Product Strategy', 'Agile', 'User Stories', 'Roadmapping'],
    capacityPercent: 100,
    timeOff: []
  },
  {
    id: 'p-david',
    name: 'David Kalu',
    role: 'Fullstack Engineer',
    team: 'Engineering',
    skills: ['React', 'Node.js', 'SQL', 'AWS'],
    capacityPercent: 100,
    timeOff: [
      {
        id: 'to-david-july',
        description: 'Casual Break',
        startDate: '2026-07-20',
        endDate: '2026-07-24'
      }
    ]
  },
  {
    id: 'p-yuki',
    name: 'Yuki Tanaka',
    role: 'Visual Web Developer',
    team: 'Design',
    skills: ['CSS', 'Tailwind CSS', 'Figma', 'React'],
    capacityPercent: 80, // Part-time resource
    timeOff: []
  },
  {
    id: 'p-clara',
    name: 'Clara Dupont',
    role: 'QA Automation Engineer',
    team: 'QA',
    skills: ['Selenium', 'Jest', 'TypeScript', 'CI/CD'],
    capacityPercent: 100,
    timeOff: [
      {
        id: 'to-clara-august',
        description: 'Summer Camp PM',
        startDate: '2026-08-03',
        endDate: '2026-08-07'
      }
    ]
  },
  {
    id: 'p-james',
    name: 'James Henderson',
    role: 'Business Analyst',
    team: 'Product',
    skills: ['Financial Modeling', 'Market Analysis', 'Requirements Gathering'],
    capacityPercent: 50, // Shared resource
    timeOff: []
  }
];

export const INITIAL_PROJECTS: Project[] = [
  {
    id: 'proj-atlas',
    name: 'Project Atlas',
    description: 'Core platform migration to modern React architecture and enterprise database upgrade.',
    startDate: '2026-06-01',
    endDate: '2026-11-15',
    priority: 'High',
    requiredSkills: ['React', 'Node.js', 'System Architecture', 'SQL', 'Product Strategy']
  },
  {
    id: 'proj-beacon',
    name: 'Project Beacon',
    description: 'New interactive client onboarding portal and real-time leadership analytics dashboards.',
    startDate: '2026-07-01',
    endDate: '2026-12-15',
    priority: 'Medium',
    requiredSkills: ['React', 'TypeScript', 'Figma', 'UI Design', 'User Stories']
  },
  {
    id: 'proj-citadel',
    name: 'Project Citadel',
    description: 'Critical cyber security hardening, encryption key rotation, and compliance auditing.',
    startDate: '2026-06-15',
    endDate: '2026-09-30',
    priority: 'Critical',
    requiredSkills: ['Security', 'System Architecture', 'Docker', 'CI/CD']
  },
  {
    id: 'proj-horizon',
    name: 'Project Horizon',
    description: 'Exploratory business modeling and research for AI-driven automated server fleet management.',
    startDate: '2026-08-01',
    endDate: '2026-12-31',
    priority: 'Low',
    requiredSkills: ['Python', 'Product Strategy', 'User Research']
  }
];

export const INITIAL_ALLOCATIONS: Allocation[] = [
  // Project Atlas staffing
  {
    id: 'alloc-atlas-priya',
    personId: 'p-priya',
    projectId: 'proj-atlas',
    percentage: 50,
    startDate: '2026-06-01',
    endDate: '2026-11-15'
  },
  {
    id: 'alloc-atlas-alex',
    personId: 'p-alex',
    projectId: 'proj-atlas',
    percentage: 40,
    startDate: '2026-06-01',
    endDate: '2026-11-15'
  },
  {
    id: 'alloc-atlas-sarah',
    personId: 'p-sarah',
    projectId: 'proj-atlas',
    percentage: 40,
    startDate: '2026-06-01',
    endDate: '2026-11-15'
  },
  {
    id: 'alloc-atlas-marcus',
    personId: 'p-marcus',
    projectId: 'proj-atlas',
    percentage: 30,
    startDate: '2026-06-01',
    endDate: '2026-11-15'
  },
  {
    id: 'alloc-atlas-elena',
    personId: 'p-elena',
    projectId: 'proj-atlas',
    percentage: 30,
    startDate: '2026-06-01',
    endDate: '2026-11-15'
  },
  {
    id: 'alloc-atlas-david',
    personId: 'p-david',
    projectId: 'proj-atlas',
    percentage: 20,
    startDate: '2026-06-01',
    endDate: '2026-11-15'
  },

  // Project Beacon staffing
  {
    id: 'alloc-beacon-alex',
    personId: 'p-alex',
    projectId: 'proj-beacon',
    percentage: 60,
    startDate: '2026-07-01',
    endDate: '2026-12-15'
  },
  {
    id: 'alloc-beacon-marcus',
    personId: 'p-marcus',
    projectId: 'proj-beacon',
    percentage: 50,
    startDate: '2026-07-01',
    endDate: '2026-12-15'
  },
  {
    id: 'alloc-beacon-elena',
    personId: 'p-elena',
    projectId: 'proj-beacon',
    percentage: 30,
    startDate: '2026-07-01',
    endDate: '2026-12-15'
  },
  {
    id: 'alloc-beacon-david',
    personId: 'p-david',
    projectId: 'proj-beacon',
    percentage: 50,
    startDate: '2026-07-01',
    endDate: '2026-12-15'
  },
  {
    id: 'alloc-beacon-yuki',
    personId: 'p-yuki',
    projectId: 'proj-beacon',
    percentage: 30,
    startDate: '2026-07-01',
    endDate: '2026-12-15'
  },

  // Project Citadel staffing (Critical)
  {
    id: 'alloc-citadel-priya',
    personId: 'p-priya',
    projectId: 'proj-citadel',
    percentage: 60, // Total Priyas workload becomes 50% Atlas + 60% Citadel = 110%!
    startDate: '2026-06-15',
    endDate: '2026-09-30'
  },
  {
    id: 'alloc-citadel-sarah',
    personId: 'p-sarah',
    projectId: 'proj-citadel',
    percentage: 50,
    startDate: '2026-06-15',
    endDate: '2026-09-30'
  },

  // Project Horizon staffing (James only, leaving skill gaps in Python, UI Strategy, and research)
  {
    id: 'alloc-horizon-james',
    personId: 'p-james',
    projectId: 'proj-horizon',
    percentage: 40,
    startDate: '2026-08-01',
    endDate: '2026-12-31'
  }
];
