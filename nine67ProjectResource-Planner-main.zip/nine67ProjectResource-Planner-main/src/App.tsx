/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

import React, { useState, useEffect } from 'react';
import { Person, Project, Allocation } from './types';
import { INITIAL_PEOPLE, INITIAL_PROJECTS, INITIAL_ALLOCATIONS } from './data';
import DashboardStats from './components/DashboardStats';
import TimelineView from './components/TimelineView';
import PeopleList from './components/PeopleList';
import ProjectsList from './components/ProjectsList';
import AiChatAssistant from './components/AiChatAssistant';
import { Sparkles, Calendar, Users, FolderKanban, Info, CheckCircle2, ChevronRight, HelpCircle, Shuffle, Search, Filter } from 'lucide-react';

const LOCAL_STORAGE_PEOPLE = 'portfolio_people_v1';
const LOCAL_STORAGE_PROJECTS = 'portfolio_projects_v1';
const LOCAL_STORAGE_ALLOCATIONS = 'portfolio_allocations_v1';

export default function App() {
  // --- BASE STATES (OFFICIAL WORKING PLAN) ---
  const [people, setPeople] = useState<Person[]>([]);
  const [projects, setProjects] = useState<Project[]>([]);
  const [allocations, setAllocations] = useState<Allocation[]>([]);
  
  // --- INTERACTIVE AI ASSISTANCE BRIDGE ---
  const [aiPrefilledPrompt, setAiPrefilledPrompt] = useState<string | null>(null);

  const handleRequestAiHelp = (prompt: string) => {
    setAiPrefilledPrompt(prompt);
    // Smoothly focus or scroll to AI assistant
    const chatElement = document.getElementById('ai-assistant-card');
    if (chatElement) {
      chatElement.scrollIntoView({ behavior: 'smooth', block: 'center' });
    }
  };

  // --- WHAT-IF SANDBOX SCENARIOS STATES ---
  const [isSandbox, setIsSandbox] = useState(false);
  const [sandboxPeople, setSandboxPeople] = useState<Person[]>([]);
  const [sandboxProjects, setSandboxProjects] = useState<Project[]>([]);
  const [sandboxAllocations, setSandboxAllocations] = useState<Allocation[]>([]);
  const [aiSandboxNotification, setAiSandboxNotification] = useState<string | null>(null);

  // --- ACTIVE VIEW TAB ---
  const [activeTab, setActiveTab] = useState<'timeline' | 'projects' | 'people'>('timeline');

  // --- CONTROL FILTERS ---
  const [filters, setFilters] = useState({
    team: '',
    skill: '',
    project: '',
    search: ''
  });

  // --- LOAD INITIAL DATA WITH LOCALSTORAGE CACHE FALLBACKS ---
  useEffect(() => {
    const cachedPeople = localStorage.getItem(LOCAL_STORAGE_PEOPLE);
    const cachedProjects = localStorage.getItem(LOCAL_STORAGE_PROJECTS);
    const cachedAllocations = localStorage.getItem(LOCAL_STORAGE_ALLOCATIONS);

    if (cachedPeople && cachedProjects && cachedAllocations) {
      setPeople(JSON.parse(cachedPeople));
      setProjects(JSON.parse(cachedProjects));
      setAllocations(JSON.parse(cachedAllocations));
    } else {
      setPeople(INITIAL_PEOPLE);
      setProjects(INITIAL_PROJECTS);
      setAllocations(INITIAL_ALLOCATIONS);
      // Cache values
      localStorage.setItem(LOCAL_STORAGE_PEOPLE, JSON.stringify(INITIAL_PEOPLE));
      localStorage.setItem(LOCAL_STORAGE_PROJECTS, JSON.stringify(INITIAL_PROJECTS));
      localStorage.setItem(LOCAL_STORAGE_ALLOCATIONS, JSON.stringify(INITIAL_ALLOCATIONS));
    }
  }, []);

  // --- SYNCHRONIZE ACTIVE DB TO LOCAL STORAGE ---
  const saveToLocalStorage = (newPeople: Person[], newProjects: Project[], newAllocs: Allocation[]) => {
    localStorage.setItem(LOCAL_STORAGE_PEOPLE, JSON.stringify(newPeople));
    localStorage.setItem(LOCAL_STORAGE_PROJECTS, JSON.stringify(newProjects));
    localStorage.setItem(LOCAL_STORAGE_ALLOCATIONS, JSON.stringify(newAllocs));
  };

  // --- DERIVED WORKING POOLS REGISTRATION (SANDBOX VS ACTIVE MODE) ---
  const currentPeople = isSandbox ? sandboxPeople : people;
  const currentProjects = isSandbox ? sandboxProjects : projects;
  const currentAllocations = isSandbox ? sandboxAllocations : allocations;

  // --- EXPLICIT SANDBOX CONTROL FUNCS ---
  const enableSandboxMode = () => {
    setSandboxPeople(JSON.parse(JSON.stringify(people)));
    setSandboxProjects(JSON.parse(JSON.stringify(projects)));
    setSandboxAllocations(JSON.parse(JSON.stringify(allocations)));
    setIsSandbox(true);
    setAiSandboxNotification("Welcome! What-If sandbox mode activated. Perform trial staffing risk-free.");
  };

  const commitSandboxToActive = () => {
    setPeople(sandboxPeople);
    setProjects(sandboxProjects);
    setAllocations(sandboxAllocations);
    saveToLocalStorage(sandboxPeople, sandboxProjects, sandboxAllocations);
    setIsSandbox(false);
    setAiSandboxNotification("Sandbox merged successfully! Official active plan updated with all current scenario modifications.");
  };

  const discardSandboxChanges = () => {
    setIsSandbox(false);
    setSandboxPeople([]);
    setSandboxProjects([]);
    setSandboxAllocations([]);
    setAiSandboxNotification(null);
  };

  // --- DATA MUTATORS ---

  // People operations
  const handleAddPerson = (p: Person) => {
    if (isSandbox) {
      const updated = [...sandboxPeople, p];
      setSandboxPeople(updated);
    } else {
      const updated = [...people, p];
      setPeople(updated);
      saveToLocalStorage(updated, projects, allocations);
    }
  };

  const handleUpdatePerson = (p: Person) => {
    if (isSandbox) {
      const updated = sandboxPeople.map(item => item.id === p.id ? p : item);
      setSandboxPeople(updated);
    } else {
      const updated = people.map(item => item.id === p.id ? p : item);
      setPeople(updated);
      saveToLocalStorage(updated, projects, allocations);
    }
  };

  const handleRemovePerson = (id: string) => {
    // Cascadely delete references
    if (isSandbox) {
      const updatedPeople = sandboxPeople.filter(item => item.id !== id);
      const updatedAllocs = sandboxAllocations.filter(alloc => alloc.personId !== id);
      setSandboxPeople(updatedPeople);
      setSandboxAllocations(updatedAllocs);
    } else {
      const updatedPeople = people.filter(item => item.id !== id);
      const updatedAllocs = allocations.filter(alloc => alloc.personId !== id);
      setPeople(updatedPeople);
      setAllocations(updatedAllocs);
      saveToLocalStorage(updatedPeople, projects, updatedAllocs);
    }
  };

  // Project operations
  const handleAddProject = (p: Project) => {
    if (isSandbox) {
      const updated = [...sandboxProjects, p];
      setSandboxProjects(updated);
    } else {
      const updated = [...projects, p];
      setProjects(updated);
      saveToLocalStorage(people, updated, allocations);
    }
  };

  const handleUpdateProject = (p: Project) => {
    if (isSandbox) {
      const updated = sandboxProjects.map(item => item.id === p.id ? p : item);
      setSandboxProjects(updated);
    } else {
      const updated = projects.map(item => item.id === p.id ? p : item);
      setProjects(updated);
      saveToLocalStorage(people, updated, allocations);
    }
  };

  const handleRemoveProject = (id: string) => {
    // Cascadely delete references
    if (isSandbox) {
      const updatedProj = sandboxProjects.filter(p => p.id !== id);
      const updatedAllocs = sandboxAllocations.filter(alloc => alloc.projectId !== id);
      setSandboxProjects(updatedProj);
      setSandboxAllocations(updatedAllocs);
    } else {
      const updatedProj = projects.filter(p => p.id !== id);
      const updatedAllocs = allocations.filter(alloc => alloc.projectId !== id);
      setProjects(updatedProj);
      setAllocations(updatedAllocs);
      saveToLocalStorage(people, updatedProj, updatedAllocs);
    }
  };

  // Allocation operations
  const handleAddAllocation = (alloc: Allocation) => {
    if (isSandbox) {
      const updated = [...sandboxAllocations, alloc];
      setSandboxAllocations(updated);
    } else {
      const updated = [...allocations, alloc];
      setAllocations(updated);
      saveToLocalStorage(people, projects, updated);
    }
  };

  const handleRemoveAllocation = (id: string) => {
    if (isSandbox) {
      const updated = sandboxAllocations.filter(a => a.id !== id);
      setSandboxAllocations(updated);
    } else {
      const updated = allocations.filter(a => a.id !== id);
      setAllocations(updated);
      saveToLocalStorage(people, projects, updated);
    }
  };

  // --- AI MASS INTEGRATOR SYNC FUNCTION ---
  const handleAiUpdateState = (
    aiPeople: Person[],
    aiProjects: Project[],
    aiAllocations: Allocation[],
    actionApplied: string | null,
    explanation: string
  ) => {
    // Grounding AI changes strictly inside sandbox mode automatically if sandbox is active,
    // or applying directly to active plan if sandbox is disabled (following user's preference!)
    if (isSandbox) {
      setSandboxPeople(aiPeople);
      setSandboxProjects(aiProjects);
      setSandboxAllocations(aiAllocations);
    } else {
      // Prompt user option or auto-save in non-sandbox mode
      setPeople(aiPeople);
      setProjects(aiProjects);
      setAllocations(aiAllocations);
      saveToLocalStorage(aiPeople, aiProjects, aiAllocations);
    }

    if (actionApplied) {
      setAiSandboxNotification(`AI applied scenario updates: "${actionApplied}"!`);
    }
  };

  // Restores standard preloaded data resets
  const handleFullResetToDefaults = () => {
    const confirm = window.confirm("Are you sure you want to restore the planning tool to its pre-filled defaults? This will erase custom resources or plans you logged.");
    if (confirm) {
      setPeople(INITIAL_PEOPLE);
      setProjects(INITIAL_PROJECTS);
      setAllocations(INITIAL_ALLOCATIONS);
      saveToLocalStorage(INITIAL_PEOPLE, INITIAL_PROJECTS, INITIAL_ALLOCATIONS);
      setIsSandbox(false);
      setAiSandboxNotification("Planning tool successfully reset to pre-filled sample defaults.");
    }
  };

  // --- EXTRAPOLATING FILTER MENUS FROM ACTIVE DIRECTORIES ---
  const uniqueTeams = Array.from(new Set(currentPeople.map(p => p.team))).filter(Boolean);
  const uniqueSkills = Array.from(new Set(currentPeople.flatMap(p => p.skills))).filter(Boolean).sort();

  return (
    <div className="min-h-screen bg-slate-50 flex flex-col font-sans select-none selection:bg-indigo-150">
      
      {/* GLOWING WHAT-IF SCENARIO WARNING BANNER */}
      {isSandbox ? (
        <div className="bg-amber-500 text-slate-950 px-4 py-2.5 text-center text-xs font-semibold flex flex-col sm:flex-row items-center justify-center gap-3 shadow-md animate-fade-in border-b border-amber-600 font-mono">
          <span>🛠️ WHAT-IF SANDBOX MODE ACTIVE • All edits and AI updates stay in this isolated testing scenario.</span>
          <div className="flex items-center gap-2">
            <button
              onClick={commitSandboxToActive}
              className="px-3 py-1 bg-slate-950 text-white rounded font-bold hover:bg-slate-900 transition text-[11px]"
            >
              Merge Scenario to Active Plan
            </button>
            <button
              onClick={discardSandboxChanges}
              className="px-2.5 py-1 bg-white border border-slate-300 text-slate-800 rounded font-bold hover:bg-slate-100 transition text-[11px]"
            >
              Discard and Reset Sandbox
            </button>
          </div>
        </div>
      ) : (
        <div className="bg-slate-900 text-slate-350 px-4 py-1.5 text-center text-[11px] font-medium flex items-center justify-center gap-2 border-b border-slate-800">
          <span>Official Active Portfolio Plan. Want to try changes risk-free?</span>
          <button
            onClick={enableSandboxMode}
            className="text-amber-400 font-bold hover:text-amber-300 hover:underline flex items-center gap-0.5"
          >
            <Shuffle className="h-3 w-3 inline" /> Open What-If Sandbox
          </button>
        </div>
      )}

      {/* DYNAMIC SYSTEM POPUP ALERTS */}
      {aiSandboxNotification && (
        <div className="bg-emerald-50 border-b border-emerald-150 text-emerald-800 px-4 py-2 text-center text-xs font-medium flex items-center justify-center gap-2">
          <CheckCircle2 className="h-4 w-4 text-emerald-600" />
          <span>{aiSandboxNotification}</span>
          <button 
            onClick={() => setAiSandboxNotification(null)} 
            className="ml-2 font-bold hover:opacity-75 font-mono"
          >
            ×
          </button>
        </div>
      )}

      {/* HEADER ROW BAR */}
      <header className="bg-white border-b border-gray-100 px-6 py-4 sticky top-0 z-45">
        <div className="max-w-7xl mx-auto flex flex-col md:flex-row md:items-center md:justify-between gap-4">
          
          <div className="flex items-center gap-3">
            <div className="p-2.5 bg-indigo-600 text-white rounded-2xl shadow-md border border-indigo-500/10">
              <Calendar className="h-6 w-6" />
            </div>
            <div>
              <h1 className="text-xl font-display font-extrabold text-slate-900 tracking-tight">Active Portfolio & Resource Planner</h1>
              <p className="text-xs text-slate-500 font-medium">Interactive smart capacity matrices and staffing bottleneck predictions</p>
            </div>
          </div>

          <div className="flex flex-wrap items-center gap-2 md:self-end">
            <button
              onClick={handleFullResetToDefaults}
              className="px-3 py-1.5 bg-white border border-gray-200 text-gray-500 hover:text-indigo-600 hover:border-indigo-100 rounded-xl text-xs font-semibold transition"
              title="Reset metrics to pristine defaults"
            >
              Reset to Pre-loaded Defaults
            </button>
            
            {!isSandbox && (
              <button
                onClick={enableSandboxMode}
                className="px-3.5 py-1.5 bg-amber-500 hover:bg-amber-600 text-slate-950 font-bold rounded-xl text-xs flex items-center gap-1.5 transition shadow-xs"
              >
                <Shuffle className="h-4 w-4" /> Start "What-If" Planning
              </button>
            )}
          </div>

        </div>
      </header>

      {/* MAIN CONTAINER CONTENT */}
      <main className="flex-1 max-w-7xl w-full mx-auto p-4 sm:p-6 space-y-6">
        
        {/* TOP LEVEL PORTFOLIO COUNTERS */}
        <DashboardStats 
          people={currentPeople} 
          projects={currentProjects} 
          allocations={currentAllocations} 
          onRequestAiHelp={handleRequestAiHelp}
        />

        {/* CONTROLS BAR: FILTERS AND MULTI SEARCH BOX */}
        <div id="filter-controls-row" className="bg-white p-4 rounded-2xl border border-gray-100 shadow-3xs flex flex-col md:flex-row gap-3 items-center justify-between">
          
          {/* SEARCH FIELD */}
          <div className="relative w-full md:w-80">
            <Search className="absolute left-3.5 top-1/2 transform -translate-y-1/2 text-gray-400 h-4.5 w-4.5" />
            <input
              type="text"
              value={filters.search}
              onChange={(e) => setFilters({ ...filters, search: e.target.value })}
              placeholder="Search resource, roles, or competence..."
              className="w-full text-xs pl-10 pr-4 py-2.5 bg-gray-50 border border-gray-150 rounded-xl focus:outline-none focus:ring-1 focus:ring-indigo-500 focus:bg-white transition"
            />
          </div>

          {/* DROP DOWNS SELECT FILTER */}
          <div className="flex flex-wrap items-center gap-2.5 w-full md:w-auto">
            <div className="flex items-center gap-1 bg-gray-50 px-2.5 py-1.5 rounded-xl border border-gray-150">
              <Filter className="h-3.5 w-3.5 text-gray-400" />
              <span className="text-[10px] uppercase font-bold text-gray-400 font-mono">Filters</span>
            </div>

            <select
              value={filters.team}
              onChange={(e) => setFilters({ ...filters, team: e.target.value })}
              className="text-xs bg-white border border-gray-150 rounded-xl px-2.5 py-2 focus:outline-indigo-500 cursor-pointer"
            >
              <option value="">All Teams</option>
              {uniqueTeams.map(t => (
                <option key={t} value={t}>{t} Team</option>
              ))}
            </select>

            <select
              value={filters.skill}
              onChange={(e) => setFilters({ ...filters, skill: e.target.value })}
              className="text-xs bg-white border border-gray-150 rounded-xl px-2.5 py-2 focus:outline-indigo-500 cursor-pointer"
            >
              <option value="">All Skills</option>
              {uniqueSkills.map(s => (
                <option key={s} value={s}>{s}</option>
              ))}
            </select>

            <select
              value={filters.project}
              onChange={(e) => setFilters({ ...filters, project: e.target.value })}
              className="text-xs bg-white border border-gray-150 rounded-xl px-2.5 py-2 focus:outline-indigo-500 cursor-pointer"
            >
              <option value="">All Projects</option>
              {currentProjects.map(proj => (
                <option key={proj.id} value={proj.id}>{proj.name}</option>
              ))}
            </select>

            {(filters.team || filters.skill || filters.project || filters.search) && (
              <button
                onClick={() => setFilters({ team: '', skill: '', project: '', search: '' })}
                className="text-xs text-indigo-600 hover:text-indigo-800 font-bold underline"
              >
                Clear Filters
              </button>
            )}
          </div>
        </div>

        {/* SPLIT SCREEN LAYOUT PANEL: LEFT SIDE CHAT, RIGHT SIDE MANAGEMENT TABS */}
        <div className="grid grid-cols-1 lg:grid-cols-12 gap-6">
          
          {/* LEFT 5 COLUMNS: AI CHAT ASSISTANT PANEL */}
          <div className="lg:col-span-5 h-[650px]">
            <AiChatAssistant 
              people={currentPeople} 
              projects={currentProjects} 
              allocations={currentAllocations} 
              onAiUpdateState={handleAiUpdateState} 
              prefilledPrompt={aiPrefilledPrompt}
              onClearPrefilledPrompt={() => setAiPrefilledPrompt(null)}
            />
          </div>

          {/* RIGHT 7 COLUMNS: MANAGEMENT PANELS */}
          <div className="lg:col-span-7 flex flex-col gap-4">
            
            {/* TABS SELECT NAVIGATION HEADER */}
            <div className="bg-white p-1 rounded-xl border border-gray-150/70 shadow-3xs flex gap-1">
              <button
                onClick={() => setActiveTab('timeline')}
                className={`flex-1 py-2 rounded-lg text-xs font-bold transition flex items-center justify-center gap-1.5 ${
                  activeTab === 'timeline'
                    ? 'bg-indigo-600 text-white shadow-xs'
                    : 'text-gray-500 hover:bg-gray-50 hover:text-gray-700'
                }`}
              >
                <Calendar className="h-4 w-4" />
                Capacity Timeline
              </button>
              
              <button
                onClick={() => setActiveTab('projects')}
                className={`flex-1 py-2 rounded-lg text-xs font-bold transition flex items-center justify-center gap-1.5 ${
                  activeTab === 'projects'
                    ? 'bg-indigo-600 text-white shadow-xs'
                    : 'text-gray-500 hover:bg-gray-50 hover:text-gray-700'
                }`}
              >
                <FolderKanban className="h-4 w-4" />
                Initiatives & Staffing
              </button>

              <button
                onClick={() => setActiveTab('people')}
                className={`flex-1 py-2 rounded-lg text-xs font-bold transition flex items-center justify-center gap-1.5 ${
                  activeTab === 'people'
                    ? 'bg-indigo-600 text-white shadow-xs'
                    : 'text-gray-500 hover:bg-gray-50 hover:text-gray-700'
                }`}
              >
                <Users className="h-4 w-4" />
                Team Roster
              </button>
            </div>

            {/* TAB CONTENTS PANES */}
            <div className="flex-1">
              {activeTab === 'timeline' && (
                <TimelineView 
                  people={currentPeople} 
                  projects={currentProjects} 
                  allocations={currentAllocations} 
                  filters={filters} 
                  onRequestAiHelp={handleRequestAiHelp}
                />
              )}

              {activeTab === 'projects' && (
                <ProjectsList 
                  projects={currentProjects} 
                  people={currentPeople} 
                  allocations={currentAllocations} 
                  onAddProject={handleAddProject} 
                  onUpdateProject={handleUpdateProject} 
                  onRemoveProject={handleRemoveProject} 
                  onAddAllocation={handleAddAllocation} 
                  onRemoveAllocation={handleRemoveAllocation} 
                  onRequestAiHelp={handleRequestAiHelp}
                />
              )}

              {activeTab === 'people' && (
                <PeopleList 
                  people={currentPeople} 
                  onAddPerson={handleAddPerson} 
                  onUpdatePerson={handleUpdatePerson} 
                  onRemovePerson={handleRemovePerson} 
                />
              )}
            </div>

          </div>

        </div>

      </main>

      {/* FOOTER METRICS INFO */}
      <footer className="bg-slate-900 border-t border-slate-800 text-slate-450 mt-12 py-8 px-6 text-xs text-center font-medium font-mono select-none">
        <div className="max-w-7xl mx-auto space-y-2">
          <p className="text-slate-400">Resource and Project Planner © 2026. Made with Google AI Studio.</p>
          <p className="text-slate-500 text-[10px]">
            Server processes grounded on dynamic planning parameters (June 3, 2026). Built using React, Tailwind CSS, and Gemini 3.5-Flash.
          </p>
        </div>
      </footer>

    </div>
  );
}
