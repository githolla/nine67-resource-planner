/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

export interface TimeOff {
  id: string;
  description: string;
  startDate: string; // YYYY-MM-DD
  endDate: string; // YYYY-MM-DD
}

export interface Person {
  id: string;
  name: string;
  role: string;
  team: string;
  skills: string[];
  capacityPercent: number; // e.g., 100 for full-time, 80 for part-time
  timeOff: TimeOff[];
}

export interface Project {
  id: string;
  name: string;
  description: string;
  startDate: string; // YYYY-MM-DD
  endDate: string; // YYYY-MM-DD
  priority: 'Critical' | 'High' | 'Medium' | 'Low';
  requiredSkills: string[];
}

export interface Allocation {
  id: string;
  personId: string;
  projectId: string;
  percentage: number; // e.g., 20, 50, 100
  startDate: string; // YYYY-MM-DD
  endDate: string; // YYYY-MM-DD
}

export interface ChatMessage {
  id: string;
  sender: 'user' | 'assistant';
  text: string;
  timestamp: string;
  aiAction?: string; // Descriptive text if the AI performed an action
}
